<footer class="main-footer">
    <div class="footer-left">
      Made By Uskudar University Software Team
    </div>
    <div class="footer-right">
      V {{\App\Models\Setting::find(1)->app_version}}
    </div>
</footer>
