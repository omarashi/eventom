<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.layout.breadcrumbs', [
        'title' => __('My Tickets'),
        'page' => __('Tickets'),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <section class="contact">
        <div class="container">
            <div class="row">
                <?php if(count($ticket['upcoming'])==0 && count($ticket['past'])==0): ?>
                    <div class="col-lg-12 text-center">
                        <div class="empty-state">
                            <img src="<?php echo e(url('frontend/images/empty.png')); ?>">
                            <h6 class="mt-4"> <?php echo e(__('No Tickets found')); ?>!</h6>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-lg-4 order-left">
                        <?php if(count($ticket['upcoming'])>0): ?>
                            <div>
                                <h5 class="mb-3"><?php echo e(__('Upcoming Events')); ?>

                                    <button><?php echo e(count($ticket['upcoming'])); ?></button>
                                </h5>
                                <?php $__currentLoopData = $ticket['upcoming']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->iteration==1): ?>
                                        <?php $first_item = $item; ?>
                                    <?php endif; ?>

                                    <?php   if ($item->order_status == "Pending") {
                                        $s = 'badge-warning';
                                    } else if ($item->order_status == "Complete") {
                                        $s = 'badge-success';
                                    } else if ($item->order_status == "Cancel") {
                                        $s = 'badge-danger';
                                    } ?>
                                    <div class="row event-data mb-3 pb-2 <?php echo e($loop->iteration==1?'active': ''); ?>" id="order-<?php echo e($item->id); ?>">
                                        <div class="col-3">
                                            <img src="<?php echo e(url('images/upload/'.$item->event->image)); ?>">
                                        </div>
                                        <div class="col-9">
                                            <span class="badge text-white mr-2 <?php echo e($s); ?>"><?php echo e($item->order_id); ?></span><span
                                                class="event-date"><?php echo e($item->event->start_time->format('D').', '.$item->event->start_time->format('d M Y')); ?></span>
                                            <h6 class="mb-1"><?php echo e($item->event->name); ?></h6>
                                            <p class="mb-0"><?php echo e($item->quantity.__(' tickets of ').$item->ticket->ticket_number); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <?php if(count($ticket['past'])>0): ?>
                            <h5 class="mt-4 mb-3"><?php echo e(__('Past Events')); ?>

                                <button><?php echo e(count($ticket['past'])); ?></button>
                            </h5>
                            <?php $__currentLoopData = $ticket['past']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php   if ($item->order_status == "Pending") {
                                    $s = 'badge-warning';
                                } else if ($item->order_status == "Complete") {
                                    $s = 'badge-success';
                                } else if ($item->order_status == "Cancel") {
                                    $s = 'badge-danger';
                                } ?>
                                <?php if($loop->iteration==1 && count($ticket['upcoming'])==0): ?>
                                    <?php $first_item = $item; ?>
                                <?php endif; ?>
                                <div class="row event-data mb-3 pb-2" id="order-<?php echo e($item->id); ?>">
                                    <div class="col-3">
                                        <img src="<?php echo e(url('images/upload/'.$item->event->image)); ?>">
                                    </div>
                                    <div class="col-9">
                                        <span class="badge text-white mr-2 <?php echo e($s); ?>"><?php echo e($item->order_id); ?></span><span
                                            class="event-date"><?php echo e($item->event->start_time->format('D').', '.$item->event->start_time->format('d M Y')); ?></span>
                                        <h6 class="mb-1"><?php echo e($item->event->name); ?></h6>
                                        <p class="mb-0"><?php echo e($item->quantity.' tickets of '.$item->ticket->ticket_number); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-8">
                        <?php
                        if ($first_item->order_status == "Pending") {
                            $status = 'badge-warning';
                        } else if ($first_item->order_status == "Complete") {
                            $status = 'badge-success';
                        } else if ($first_item->order_status == "Cancel") {
                            $status = 'badge-danger';
                        }
                        $review = App\Models\Review::where('order_id', $first_item->id)->first();
                        ?>

                        <div class="single-order">
                            <div class="single-order-top">
                                <p class="text-light mb-0"><?php echo e($first_item->order_id); ?></p>
                                <h2><?php echo e($first_item->event->start_time->format('D').', '.$first_item->event->start_time->format('d M Y').' at '. $first_item->event->start_time->format('h:i a')); ?></h2>
                                <span class="badge <?php echo e($status); ?>"><?php echo e($first_item->order_status); ?></span>
                                <?php if($review!=null): ?>
                                    <div class="rating order-rate">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <i class="fa fa-star <?php echo e($review->rate >= $i ? 'active':''); ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="row mt-2">
                                    <div class="col-lg-2">
                                        <img class="w-100" src="<?php echo e(url('images/upload/'.$item->event->image)); ?>">
                                    </div>

                                    <div class="col-5">
                                        <h6 class="mb-0"><?php echo e($first_item->event->name); ?></h6>
                                        <p class="mb-0"><?php echo e(__('By')); ?>: <?php echo e($first_item->organization->first_name.' '.$first_item->organization->last_name); ?></p>
                                        <p class="mb-0"><?php echo e($first_item->event->start_time->format('d M Y').', '. $first_item->event->start_time->format('h:i a'). ' to '); ?></p>
                                        <p class="mb-0"><?php echo e($first_item->event->end_time->format('d M Y').', '. $first_item->event->end_time->format('h:i a')); ?></p>
                                        <?php if($first_item->event->type=="online"): ?>
                                            <p class="mb-0"><?php echo e(__('Online Event')); ?></p>
                                        <?php else: ?>
                                            <p class="mb-0"><?php echo e($first_item->event->address); ?></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-5 ">
                                        <div class="right-data text-center">
                                            <div>
                                                <button class="btn" onclick="viewPayment()"><i class="fa fa-credit-card"></i></button>
                                                <p><?php echo e(__('Payment')); ?></p>
                                            </div>
                                            <?php if($review == null && $first_item->order_status=="Complete" || $first_item->order_status=="Cancel"): ?>
                                                <div>
                                                    <button class="btn open-addReview" data-toggle="modal" data-id="<?php echo e($first_item->id); ?>" data-order="<?php echo e($first_item->order_id); ?>"
                                                            data-target="#reviewModel"><i class="fa fa-star"></i></button>
                                                    <p><?php echo e(__('Review')); ?></p>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <a href="<?php echo e(url('order-invoice-print/' . $first_item->id)); ?>" target="_blank" class="btn" id="print-btn"><i class="fa fa-print"></i>
                                                    <p><?php echo e(__('Print')); ?></p></a>
                                            </div>
                                            <?php if($first_item->order_status != "Cancel"): ?>
                                                <div>
                                                    <form id="cancel-order-<?php echo e($first_item->id); ?>" action="<?php echo e(url('cancelOrder/' . $first_item->id)); ?>" method="post" style="display: none;"><?php echo csrf_field(); ?></form>
                                                    <a href="javascript:void(0)" class="btn" id="cancel-btn" onclick="event.preventDefault(); var confirm = window.confirm('Are You Sure ?'); if
                                                    (confirm) { $('#cancel-order-<?php echo e($first_item->id); ?>').submit(); }
                                                    "><i
                                                            class="fa fa-ban"></i>
                                                        <p><?php echo e(__('Cancel')); ?></p></a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="payment-data hide">
                                            <p class="mb-0"><span><?php echo e(__('Payment Method')); ?> : </span><?php echo e($first_item->payment_type); ?></p>
                                            <p class="mb-1"><span><?php echo e(__('Payment Token')); ?> : </span><?php echo e($first_item->payment_token==null?'-':$first_item->payment_token); ?></p>
                                            <span class="badge <?php echo e($first_item->payment_status==1?'badge-success':'badge-warning'); ?>"><?php echo e($first_item->payment_status==1?'Paid':'Waiting'); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="order-bottom">
                                <div class="order-ticket-detail mb-4">
                                    <div>
                                        <p><?php echo e($first_item->ticket->name); ?></p>
                                    </div>
                                    <div>
                                        <?php if($first_item->ticket->type=="free"): ?>
                                            <?php echo e($first_item->quantity .' tickets'); ?>

                                        <?php else: ?>
                                            <?php echo e($first_item->quantity.' * '.$currency.$first_item->ticket->price); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="order-total">
                                    <p><?php echo e(__('Ticket Price')); ?></p>
                                    <p><?php echo e($first_item->ticket->type=="free"?'FREE':$currency.($first_item->ticket->price* $item->quantity)); ?></p>
                                </div>
                                <div class="order-total">
                                    <p><?php echo e(__('Coupon discount')); ?></p>
                                    <p><?php echo e($first_item->ticket->type=="free"?'0.00':'(-) '.$currency.$first_item->coupon_discount); ?></p>
                                </div>
                                <div class="order-total">
                                    <p><?php echo e(__('Tax')); ?></p>
                                    <p><?php echo e($first_item->ticket->type=="free"?'0.00':'(+) '.$currency.$first_item->tax); ?></p>
                                </div>
                                <div class="order-total">
                                    <h6><?php echo e(__('Total')); ?></h6>
                                    <h6><?php echo e($first_item->ticket->type=="free"?'FREE':$currency.$first_item->payment); ?></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <div class="modal fade" id="reviewModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(__('Add Review')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="<?php echo e(url('add-review')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo e(__('Rate')); ?></label>
                            <input type="hidden" name="order_id" id="order_id">
                            <input type="hidden" name="rate" required>
                            <div class="rating">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa fa-star" onclick="addRate('<?php echo e($i); ?>');" id="rate-<?php echo e($i); ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label><?php echo e(__('Message')); ?></label>
                            <textarea name="message" required class="form-control" placeholder="<?php echo e(__('Message')); ?>"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Add')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', ['activePage' => 'ticket'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/userTickets.blade.php ENDPATH**/ ?>