<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Coupon'),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="section-body">

        <div class="row">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                    <div class="row mb-4 mt-2">
                        <div class="col-lg-8"><h2 class="section-title mt-0"> <?php echo e(__('View Coupon')); ?></h2></div>
                        <div class="col-lg-4 text-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_create')): ?>
                            <button class="btn btn-primary add-button"><a href="<?php echo e(url('coupon/create')); ?>"><i class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a></button>
                            <?php endif; ?>
                        </div>
                    </div>
                  <div class="table-responsive">
                    <table class="table" id="report_table">
                        <thead>
                            <tr>
                                <th></th>
                                <th><?php echo e(__('Coupon Code')); ?></th>
                                <th><?php echo e(__('Name')); ?></th>
                                <th><?php echo e(__('Event')); ?></th>
                                <th><?php echo e(__('Discount')); ?></th>
                                <th><?php echo e(__('Duration')); ?></th>
                                <th><?php echo e(__('Avaliable')); ?></th>
                                <th><?php echo e(__('Status')); ?></th>
                                <?php if(Gate::check('coupon_edit') || Gate::check('coupon_delete')): ?>
                                <th><?php echo e(__('Action')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $coupon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td> <?php echo e($item->coupon_code); ?></td>
                                    <td> <?php echo e($item->name); ?></td>
                                    <td> <?php echo e($item->event->name); ?></td>
                                    <td> <?php echo e($item->discount.'%'); ?></td>
                                    <td><?php echo e($item->start_date.' to '.$item->end_date); ?></td>
                                    <td><?php echo e($item->max_use-$item->use_count.' time'); ?></td>
                                    <td>
                                        <h5><span class="badge <?php echo e($item->status=="1"?'badge-success': 'badge-warning'); ?>  m-1"><?php echo e($item->status=="1"?'Active': 'Inactive'); ?></span></h5>
                                    </td>
                                    <?php if(Gate::check('coupon_edit') || Gate::check('coupon_delete')): ?>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_edit')): ?>
                                        <a href="<?php echo e(route('coupon.edit', $item->id)); ?>" class="btn-icon"><i class="fas fa-edit"></i></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coupon_delete')): ?>
                                        <a href="javascript:void(0)"  onclick="deleteData('coupon','<?php echo e($item->id); ?>');" class="btn-icon"><i class="fas fa-trash-alt text-danger"></i></a>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/coupon/index.blade.php ENDPATH**/ ?>