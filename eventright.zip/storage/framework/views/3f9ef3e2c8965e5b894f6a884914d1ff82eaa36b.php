<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Profile'),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="section-body">
        <h2 class="section-title"><?php echo e(__('Hi,')); ?> <?php echo e(Auth::user()->name); ?>!</h2>
        <p class="section-lead">
            <?php echo e(__('Change information about yourself on this page.')); ?>

        </p>
        <div class="row mt-sm-4">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12 col-md-12 col-lg-5">
              <div class="card profile-widget">
                <div class="profile-widget-header">
                  <img alt="image" src="<?php echo e(url('images/upload/'.Auth::user()->image)); ?>" class="rounded-circle profile-widget-picture">
                  <div class="profile-widget-items">
                    <?php if(Auth::user()->hasRole('admin')): ?>
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label"><?php echo e(__('Organizations')); ?></div>
                            <div class="profile-widget-item-value"><?php echo e(App\Models\User::role('organization')->count()); ?></div>
                        </div>
                    <?php endif; ?>







                    <div class="profile-widget-item">
                      <div class="profile-widget-item-label"><?php echo e(__('Events')); ?></div>
                      <div class="profile-widget-item-value">
                        <?php if(Auth::user()->hasRole('admin')): ?>
                        <?php echo e(App\Models\Event::count()); ?>

                        <?php elseif(Auth::user()->hasRole('organization')): ?>
                        <?php echo e(App\Models\Event::where('user_id',Auth::user()->id)->count()); ?>

                        <?php endif; ?>
                        </div>
                    </div>
                  </div>
                </div>
                <div class="profile-widget-description">
                  <div class="profile-widget-name"><?php echo e(Auth::user()->name); ?></div>
                   <b><?php echo e(Auth::user()->email); ?></b>
                   <p><?php echo e(Auth::user()->bio); ?></p>
                </div>
              </div>

              <?php if(Auth::user()->hasRole('organization')): ?>

                <?php
                    $followers = \App\Models\AppUser::whereIn('id',Auth::user()->followers)->get();
                ?>























              <?php endif; ?>
            </div>
            <div class="col-12 col-md-12 col-lg-7">
              <div class="card mt-4">
                  <div class="card-header">
                    <h4><?php echo e(__('Edit Profile')); ?></h4>
                  </div>
                  <div class="card-body">
                        <form method="post" class="needs-validation" action="<?php echo e(url('edit-profile')); ?>">
                        <?php echo csrf_field(); ?>
                            <div class="text-muted d-inline"><h6><?php echo e(__('Admin Information')); ?></h6></div>
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label><?php echo e(__('Name')); ?></label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-12">
                                    <label><?php echo e(__('Email')); ?></label>
                                    <input type="email" readonly name="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>











                            <div class="form-group">
                                <label><?php echo e(__('Bio')); ?></label>
                                <textarea name="bio" placeholder="<?php echo e(__('About you')); ?>" class="form-control <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(Auth::user()->bio); ?></textarea>
                                <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php endif; ?>
                            </div>
                          <div class="form-group text-right">
                              <button type="submit" class="btn btn-primary"><?php echo e(__('Save Changes')); ?></button>
                          </div>
                      </form>
                       <form method="post" class="needs-validation" action="<?php echo e(url('change-password')); ?>">
                      <?php echo csrf_field(); ?>
                          <div class="text-muted d-inline"><h6><?php echo e(__('Change Password')); ?></h6></div>
                          <div class="row">
                              <div class="form-group col-md-12 col-12">
                                  <label><?php echo e(__('Current Password')); ?></label>
                                  <input type="password" name="current_password" Placeholder="<?php echo e(__('Current Password')); ?>" class="form-control"  required>
                                  <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feedback"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      <?php if(Session::has('error_msg')): ?>
                                          <span class="invalid-feedback block" >
                                              <?php echo e(Session::get('error_msg')); ?>

                                          </span>
                                      <?php endif; ?>
                              </div>
                          </div>
                          <div class="row">
                              <div class="form-group col-md-12 col-12">
                                  <label><?php echo e(__('New Password')); ?></label>
                                  <input type="password" name="password" placeholder="<?php echo e(__('New Password')); ?>" class="form-control" required>
                                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                          </div>
                           <div class="row">
                              <div class="form-group col-md-12 col-12">
                                  <label><?php echo e(__('Confirm Password')); ?></label>
                                  <input type="password" name="confirm_password" Placeholder="<?php echo e(__('Confirm Password')); ?>" class="form-control"  required>
                                  <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                      <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                          </div>
                          <div class="form-group text-right">
                              <button type="submit" class="btn btn-primary"><?php echo e(__('Changes')); ?></button>
                          </div>
                      </form>
                  </div>


              </div>
            </div>
          </div>


    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/profile.blade.php ENDPATH**/ ?>