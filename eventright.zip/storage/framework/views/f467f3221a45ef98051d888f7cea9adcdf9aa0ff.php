

<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Notification Template'),            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="section-body">       
       
        <div class="row">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12">
              <div class="card">     
                <div class="card-header">
                    <h5><?php echo e(__('Notification Template')); ?></h5>
                </div>
                <div class="card-body">
                    <div class="row mb-4 mt-2">
                        <div class="col-lg-8"><h2 class="section-title mt-0"> <?php echo e(__('Notification Template')); ?></h2></div>
                        <div class="col-lg-4 text-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('notification_template_create')): ?>
                            <button class="btn btn-primary add-button"><a href="<?php echo e(url('notification-template/create')); ?>"><i class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a></button>                
                            <?php endif; ?>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="template-left">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->iteration==1): ?>
                                        <?php $template = $item;?>
                                    <?php endif; ?>
                                    <div class="template-row mb-4">                                      
                                        <button onclick="notificationDetail(<?php echo e($item->id); ?>);" class="btn btn-primary template-btn"> <?php echo e($item->title); ?></button>    
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <form action="<?php echo e(url('notification-template/'.$template->id)); ?>" id="edit-template-form" method="post">
                                <?php echo csrf_field(); ?> 
                                <?php echo method_field('PUT'); ?>
                                <div class="form-group">
                                    <label><?php echo e(__('Subject')); ?></label>
                                    <input type="text" name="subject" placeholder="<?php echo e(__('Subject')); ?>" value="<?php echo e(isset($template) ? $template->subject: ''); ?>" class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('Email Content')); ?></label>
                                    <textarea name="mail_content" Placeholder ="<?php echo e(__('Email Content')); ?>" class="textarea_editor <?php $__errorArgs = ['mail_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <?php echo e(isset($template) ? $template->mail_content: ''); ?>

                                    </textarea>
                                    <?php $__errorArgs = ['mail_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label><?php echo e(__('App notification message Content')); ?></label>
                                    <textarea name="message_content" id="message_content" placeholder="<?php echo e(__('App notification message Content')); ?>" class="form-control <?php $__errorArgs = ['message_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(isset($template) ? $template->message_content: ''); ?></textarea>
                                    <?php $__errorArgs = ['message_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">                            
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>                                    
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-2">
                            <h5 class="text-muted"><?php echo e(__('Email Placeholder')); ?></h5>
                            <div class="email-holder"> 
                                <span class="d-block" data-toggle="tooltip" data-title="Customer Name" data-original-title="" title="">
                                    <button class="btn" type="button">{{user_name}}</button>
                                </span>
                                <span class="d-block" data-toggle="tooltip" data-title="Organizer Name" data-original-title="" title="">
                                    <button class="btn" type="button">{{organizer_name}}</button>
                                </span>
                                <span class="d-block" data-toggle="tooltip" data-title="Application Name" data-original-title="" title="">
                                    <button class="btn" type="button">{{app_name}}</button>
                                </span>
                                <span class="d-block" data-toggle="tooltip" data-title="Event Name" data-original-title="" title="">
                                    <button class="btn" type="button">{{event_name}}</button>
                                </span>
                                <span class="d-block" data-toggle="tooltip" data-title="Event date" data-original-title="" title="">
                                    <button class="btn" type="button">{{date}}</button>
                                </span>
                                <span class="d-block" data-toggle="tooltip" data-title="Number of purchased tickets" data-original-title="" title="">
                                    <button class="btn" type="button">{{quantity}}</button>
                                </span>
                                <span class="d-block" data-toggle="tooltip" data-title="Password" data-original-title="" title="">
                                    <button class="btn" type="button">{{password}}</button>
                                </span>                               
                            </div>
                        </div>
                    </div>                                               

                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/template/index.blade.php ENDPATH**/ ?>