<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Users'),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="section-body">

        <div class="row">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                    <div class="row mb-4 mt-2">
                        <div class="col-lg-8"><h2 class="section-title mt-0"> <?php echo e(__('View Users')); ?></h2></div>
                        <div class="col-lg-4 text-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_create')): ?>
                            <button class="btn btn-primary add-button"><a href="<?php echo e(url('users/create')); ?>"><i class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a></button>
                            <?php endif; ?>
                        </div>
                    </div>
                  <div class="table-responsive">
                    <table class="table" id="report_table">
                        <thead>
                            <tr>
                                <th></th>
                                <th><?php echo e(__('User')); ?></th>
                                <th><?php echo e(__('Phone')); ?></th>
                                <th><?php echo e(__('Role')); ?></th>
                                <?php if(Gate::check('user_edit') || Gate::check('user_delete')): ?>
                                <th><?php echo e(__('Action')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td>
                                        <div class="media">
                                            <img alt="image" class="mr-3 avatar" src="<?php echo e(url('images/upload/'.$item->image)); ?>">
                                            <div class="media-body">
                                                <div class="media-title mb-0">
                                                   <?php echo e($item->first_name.' '.$item->last_name); ?>

                                                </div>
                                                <div class="media-description text-muted"> <?php echo e($item->email); ?> </div>
                                            </div>
                                        </div>
                                    </td>
                                    
                                    <td><?php echo e($item->phone); ?></td>
                                    <td>
                                        <?php $__empty_1 = true; $__currentLoopData = $item->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <span class="badge badge-primary  m-1"><?php echo e($roles->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="badge badge-warning  m-1"><?php echo e(__('No Data')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <?php if(Gate::check('user_edit') || Gate::check('user_delete')): ?>
                                    <td>
                                        <?php if(!$item->hasRole('admin')): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_edit')): ?>
                                                <a href="<?php echo e(route('users.edit', $item->id)); ?>" class="btn-icon"><i class="fas fa-edit"></i></a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/user/index.blade.php ENDPATH**/ ?>