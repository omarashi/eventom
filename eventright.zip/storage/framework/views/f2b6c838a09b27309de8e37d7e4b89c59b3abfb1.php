

<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Roles'),            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="section-body">
    
       
        <div class="row">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12">
              <div class="card">     
                <div class="card-body">
                    <div class="row mb-4 mt-2">
                        <div class="col-lg-8"><h2 class="section-title mt-0"> <?php echo e(__('View Roles')); ?></h2></div>
                        <div class="col-lg-4 text-right">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_create')): ?>
                            <button class="btn btn-primary add-button"><a href="<?php echo e(url('roles/create')); ?>"><i class="fas fa-plus"></i> <?php echo e(__('Add New')); ?></a></button>                
                            <?php endif; ?>
                        </div>
                    </div>   
                  <div class="table-responsive">
                    <table class="table" id="report_table">
                        <thead>
                            <tr>
                                <th></th>                                
                                <th><?php echo e(__('Title')); ?></th>
                                <th><?php echo e(__('Permissions')); ?></th> 
                                <?php if(Gate::check('role_edit') || Gate::check('role_delete')): ?>                                   
                                <th style="width:130px"><?php echo e(__('Action')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>                                    
                                    <td><?php echo e($item->name); ?></td>                                                                                   
                                    <td>
                                        <?php $__empty_1 = true; $__currentLoopData = $item->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <span class="badge badge-success  m-1"><?php echo e($permission->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php if($item->name == 'admin'): ?>
                                                <span class="badge badge-warning  m-1"><?php echo e(__('All')); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-warning  m-1"><?php echo e(__('No Data')); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <?php if(Gate::check('role_edit') || Gate::check('role_delete')): ?> 
                                    <td>
                                        <?php if($item->name!="admin"): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_edit')): ?>                                        
                                            <a href="<?php echo e(route('roles.edit', $item->id)); ?>" class="btn-icon"><i class="fas fa-edit"></i></a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/role/index.blade.php ENDPATH**/ ?>