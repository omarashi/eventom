

<?php $__env->startSection('content'); ?>
 
    <?php echo $__env->make('frontend.layout.breadcrumbs', [
        'title' => __('Featured Category'),            
        'page' => __('Category'),            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<section class="property-grid grid">
    <div class="container">
      <div class="row">
        <div id="" class="category-section">
            <div class="row">
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item-c col-lg-4 col-md-6 col-sm-12">
                  <div class="card-box-b card-shadow news-box box-shadow radius-10">
                    <div class="img-box-b">
                      <img src="<?php echo e(url('images/upload/'.$item->image)); ?>" alt="" class="img-b img-fluid">
                    </div>
                    <div class="card-overlay">
                      <div class="card-header-b">                     
                        <div class="card-title-b">
                          <h2 class="title-2">
                            <a href="<?php echo e(url('events-category/'.$item->id.'/'. preg_replace('/\s+/', '-', $item->name))); ?>"><?php echo e($item->name); ?></a>
                          </h2>
                        </div>                     
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
            </div>               
          </div>                 
      </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', ['activePage' => 'category'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/allCategory.blade.php ENDPATH**/ ?>