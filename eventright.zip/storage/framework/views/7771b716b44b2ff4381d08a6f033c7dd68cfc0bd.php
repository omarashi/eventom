

<?php $__env->startSection('content'); ?>
  
    <div class="Card-sc-8zkhaa-0 styled__StyledCard-mxvrth-1 fogDtz">
        <form action="<?php echo e(url('change-password')); ?>" method="post"  data-qa="form-login" name="login">
        <?php echo csrf_field(); ?>
            <p data-qa="title" class="Text-st1i2q-0 styled__Title-sc-1subqgs-0 jTZzYs"><?php echo e(__('Change Password')); ?></p>            
            <div class="NGrUbJBA _1Z8A3Tz5 _1FaKA6Nk _3cNt_ILG LoginForm__StyledGrid-sc-1jdwe0j-1 iPBaVu">
                <div class="_1RLMtIP3 _1w0U-CY6 Qso_pkui mb-4">
                    <div class="_2iCrTJcD"><label class="_2x_Fz5Ot" data-qa="label-name"><?php echo e(__('Current Password')); ?></label></div>
                    <div class="_2fessCXR p2xx3nlH up-A7EAi">
                        <input class="RJT7RW5k" required name="old_password" type="password" placeholder="<?php echo e(__('Your Current Password')); ?>">
                    </div>
                    <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="_2OcwfRx4" data-qa="email-status-message"><?php echo e($message); ?></div>
                    <?php endif; ?>
                    <?php if(Session::has('error_msg')): ?>                            
                        <div class="_2OcwfRx4 text-danger mt-1" data-qa="email-status-message"><strong><?php echo e(Session::get('error_msg')); ?></strong></div>
                    <?php endif; ?>
                </div>
                <div class="_1RLMtIP3 Qso_pkui mb-4">
                    <div class="_2iCrTJcD"> <label class="_2x_Fz5Ot" data-qa="label-name"><?php echo e(__('New Password')); ?></label> </div>
                    <div class="_2fessCXR p2xx3nlH">
                        <input class="RJT7RW5k" required name="password" type="password" placeholder="<?php echo e(__('New password')); ?>">
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="_2OcwfRx4" data-qa="email-status-message"><?php echo e($message); ?></div>
                    <?php endif; ?>
                </div>
                <div class="_1RLMtIP3 Qso_pkui mb-4">
                    <div class="_2iCrTJcD"> <label class="_2x_Fz5Ot" data-qa="label-name"><?php echo e(__('Confirm Password')); ?></label> </div>
                    <div class="_2fessCXR p2xx3nlH">
                        <input class="RJT7RW5k" required name="password_confirmation" type="password" placeholder="<?php echo e(__('Confirm password')); ?>">
                    </div>
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="_2OcwfRx4" data-qa="email-status-message"><?php echo e($message); ?></div>
                    <?php endif; ?>
                </div>
            </div>
           
            <div class="Flex-nqja63-0 styled__ButtonWrapper-sc-1vy69nr-0 lhtHXX">
                <button type="submit" data-qa="login-button" class="styled__ButtonWrapper-sc-56doij-3 hnulbU">
                    <?php echo e(__('Change')); ?>

                </button>
            </div>
          
        </form>
    </div>
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/auth/changePassword.blade.php ENDPATH**/ ?>