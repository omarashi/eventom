<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
  <form class="form-inline mr-auto">
    <ul class="navbar-nav mr-3">
      <li><a href="javascript:void(0)" data-toggle="sidebar" class="nav-link nav-link-lg"><i class="fas fa-bars"></i></a></li>
    </ul>


  </form>
  <ul class="navbar-nav navbar-right">
    <?php if(Auth::user()->hasRole('organization')): ?>
    <li>
      <?php
        $notification = \App\Models\Notification::where('organizer_id',Auth::user()->id)->orderBy('id','DESC')->get();
      ?>

      <a href="javascript:void(0)" data-toggle="dropdown" class="nav-link notification-toggle nav-link-lg beep"><i class="far fa-bell"></i></a>
      <div class="dropdown-menu dropdown-list dropdown-menu-right">
        <div class="dropdown-header"><?php echo e(__('Notifications')); ?>

          <div class="float-right">
          </div>
        </div>

          <?php if(count($notification)==0): ?>
            <div class="dropdown-list-content dropdown-list-icons">
              <a href="javascript:void(0)" class="dropdown-item">
                <div class="dropdown-item-desc">
                  <h6><?php echo e(__('No notification found')); ?></h6>
                </div>
              </a>
            </div>
          <?php else: ?>
            <div class="dropdown-list-content dropdown-list-icons">
              <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->user!=null): ?>
                <?php if($loop->iteration<=3): ?>
                  <a href="javascript:void(0)" class="dropdown-item">
                    <div class="dropdown-item-icon bg-danger text-white">
                      <img class="avatar" src="<?php echo e(url('images/upload/'.$item->user->image)); ?>">
                    </div>
                    <div class="dropdown-item-desc">
                        <?php echo e($item->message); ?>

                        <div class="time"><?php echo e($item->created_at->diffForHumans()); ?></div>
                    </div>
                  </a>
                <?php endif; ?>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="dropdown-footer text-center">
              <a href="<?php echo e(url('notification')); ?>"><?php echo e(__('View All')); ?> <i class="fas fa-chevron-right"></i></a>
            </div>
          <?php endif; ?>
      </div>
    </li>
    <?php endif; ?>
    <?php $lang = session('locale')==null?"English":session('locale'); ?>
    <?php
        $languages = \App\Models\Language::where('status',1)->get();
    ?>












    <li class="dropdown"><a href="javascript:void(0)" data-toggle="dropdown" class="nav-link dropdown-toggle nav-link-lg nav-link-user">
    <img alt="image" src="<?php echo e(url('images/upload/'.Auth::user()->image)); ?>" class="rounded-circle mr-1">
      <div class="d-sm-none d-lg-inline-block"><?php echo e(Auth::user()->name); ?></div></a>
      <div class="dropdown-menu dropdown-menu-right">
        <div class="dropdown-title"><?php echo e(__('Welcome')); ?> <?php echo e(Auth::user()->name); ?>!</div>
        <a href="<?php echo e(url('profile')); ?>" class="dropdown-item has-icon">
          <i class="far fa-user"></i> <?php echo e(__('Profile')); ?>

        </a>
        <?php if(Auth::user()->hasRole('admin')): ?>






        <?php endif; ?>
        <div class="dropdown-divider"></div>
        <a href="<?php echo e(route('logout')); ?>" class="dropdown-item has-icon text-danger" onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
          <i class="fas fa-sign-out-alt"></i> <?php echo e(__('Logout')); ?>

        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
        </form>
      </div>
    </li>
  </ul>
</nav>
<?php /**PATH C:\laragon\www\eventright\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>