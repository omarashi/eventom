<footer class="mt-8">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <nav class="nav-footer text-right mb-2">
                    <ul class="list-inline">
                        <li class="list-inline-item">
                            <a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0)"><?php echo e(__('Organizations')); ?></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0)"><?php echo e(__('Privacy Policy')); ?></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0)"><?php echo e(__('Contact')); ?></a>
                        </li>
                    </ul>













                </nav>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\eventright\resources\views/frontend/layout/footer.blade.php ENDPATH**/ ?>