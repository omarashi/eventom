<?php $__env->startSection('content'); ?>
      <section class="section-property section-t8 section-b4">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="title-wrap d-flex justify-content-between">
                <div class="title-box">
                  <h2 class="title-a"><?php echo e(__('Latest Events')); ?></h2>
                </div>

              </div>
            </div>
          </div>
          <div id="" class="event-section owl-theme">
            <div class="row">
              <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->iteration <= 6): ?>
                <div class="carousel-item-b col-lg-4 col-md-6 col-sm-6 mb-4">
                  <div class="fav-section">
                    <?php if(Auth::guard('appuser')->check()): ?>
                      <button type="button" onclick="addFavorite(<?php echo e($item->id); ?>,'event')" class="btn p-0"> <i class="fa fa-heart <?php echo e(in_array($item->id,array_filter(explode(',',Auth::guard('appuser')->user()->favorite)))==true?'active':''); ?>"></i></button>
                    <?php else: ?>
                      <button type="button" class="btn p-0"> <a href="<?php echo e(url('user/login')); ?>"><i class="fa fa-heart"></i></a></button>
                    <?php endif; ?>
                  </div>
                  <div class="card-box-a card-shadow box-shadow radius-10">
                    <div class="img-box-a">
                      <img src="<?php echo e(url('images/upload/'.$item->image)); ?>" alt="" class="img-a img-fluid">
                    </div>
                    <div class="card-overlay">
                      <div class="card-overlay-a-content">
                        <div class="card-header-a">
                          <h2 class="card-title-a">
                            <a href="<?php echo e(url('event/'.$item->id.'/'.preg_replace('/\s+/', '-', $item->name))); ?>"><?php echo e($item->name); ?></a>
                          </h2>
                        </div>
                        <div class="card-body-a">
                          <div class="price-box d-flex">
                            <span class="price-a"><?php echo e($item->start_time->format('l').', '.$item->start_time->format('d F Y')); ?></span>
                          </div>
                          <a href="<?php echo e(url('event/'.$item->id.'/'.preg_replace('/\s+/', '-', $item->name))); ?>" class="link-a"><?php echo e(__('More Detail')); ?>

                            <span class="ion-ios-arrow-forward"></span>
                          </a>
                        </div>
                        <div class="card-footer-a">
                          <ul class="card-info d-flex justify-content-around">
                            <li>
                              <h4 class="card-info-title"><?php echo e(__('Type')); ?></h4>
                              <span><?php echo e($item->category->name); ?></span>
                            </li>
                            <li>
                              <h4 class="card-info-title"><?php echo e(__('People')); ?></h4>
                              <span><?php echo e($item->people); ?></span>
                            </li>
                            <li>
                              <h4 class="card-info-title"><?php echo e(__('Sold')); ?></h4>
                              <span><?php echo e($item->sold_ticket.' ticket'); ?> </span>
                            </li>
                            <li>
                              <h4 class="card-info-title"><?php echo e(__('Available')); ?></h4>
                              <span><?php echo e($item->available_ticket.' ticket'); ?></span>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </section>

    <section class="section-news section-t4 section-b4 mt-4 bg-gray">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-wrap d-flex justify-content-between">
              <div class="title-box">
                <h2 class="title-a"><?php echo e(__('Featured Category')); ?></h2>
              </div>
            </div>
          </div>
        </div>
        <div id="" class="category-section">
          <div class="row">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="carousel-item-c col-lg-3 col-md-6 col-sm-6">
                <div class="card-box-b card-shadow news-box radius-10">
                  <div class="img-box-b">
                    <img src="<?php echo e(url('images/upload/'.$item->image)); ?>" alt="" class="img-b img-fluid">
                  </div>
                  <div class="card-overlay">
                    <div class="card-header-b">
                      <div class="card-title-b">
                        <h2 class="title-2">
                          <a href="<?php echo e(url('events-category/'.$item->id.'/'. preg_replace('/\s+/', '-', $item->name))); ?>"><?php echo e($item->name); ?></a>
                        </h2>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </section>












































<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', ['activePage' => 'home'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/home.blade.php ENDPATH**/ ?>