

<?php $__env->startSection('content'); ?>
  
    <div class="Card-sc-8zkhaa-0 styled__StyledCard-mxvrth-1 fogDtz">
        <form action="<?php echo e(url('user/login')); ?>" method="post"  data-qa="form-login" name="login">
        <?php echo csrf_field(); ?>
            <p data-qa="title" class="Text-st1i2q-0 styled__Title-sc-1subqgs-0 jTZzYs"><?php echo e(__('Log in with email')); ?> </p>
            <input type="hidden" value="<?php echo e(url()->previous()); ?>" name="url" >
            <div class="NGrUbJBA _1Z8A3Tz5 _1FaKA6Nk _3cNt_ILG LoginForm__StyledGrid-sc-1jdwe0j-1 iPBaVu">
                <div class="_1RLMtIP3 _1w0U-CY6 Qso_pkui mb-4">
                    <div class="_2iCrTJcD"><label class="_2x_Fz5Ot" data-qa="label-name"><?php echo e(__('Email address')); ?></label></div>
                    <div class="_2fessCXR p2xx3nlH up-A7EAi">
                        <input autocomplete="off" class="RJT7RW5k" required name="email" type="email" placeholder="<?php echo e(__('Your email address')); ?>">
                    </div>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="_2OcwfRx4" data-qa="email-status-message"><?php echo e($message); ?></div>
                    <?php endif; ?>
                    <?php if(Session::has('error_msg')): ?>                            
                        <div class="_2OcwfRx4 text-danger mt-1" data-qa="email-status-message"><strong><?php echo e(Session::get('error_msg')); ?></strong></div>
                    <?php endif; ?>
                </div>
                <div class="_1RLMtIP3 Qso_pkui mb-4">
                    <div class="_2iCrTJcD"> <label class="_2x_Fz5Ot" data-qa="label-name"><?php echo e(__('Password')); ?></label> </div>
                    <div class="_2fessCXR p2xx3nlH">
                        <input autocomplete="off" class="RJT7RW5k" required name="password" type="password" placeholder="<?php echo e(__('Your password')); ?>">
                    </div>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="_2OcwfRx4" data-qa="email-status-message"><?php echo e($message); ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <p class="_9t1fKU5Y _2UdNcEai LoginForm__StyledForgotPassword-sc-1jdwe0j-0 egGnFL">
                <a href="<?php echo e(url('user/resetPassword')); ?>" data-qa="forgot-password-link" class="_2sZS6sEx XMtNYrVY _37Xq1GQz _2r41poQM k2GDOOsu _2nu1E8dp">
                    <span class="_3Li0AqmO"> <?php echo e(__('Forgot password')); ?>? </span>
                </a>
            </p>
            <div class="Flex-nqja63-0 styled__ButtonWrapper-sc-1vy69nr-0 lhtHXX">
                <button type="submit" data-qa="login-button" class="styled__ButtonWrapper-sc-56doij-3 hnulbU">
                    <?php echo e(__('Log in')); ?>

                </button>
            </div>
            <div class="styled__Container-sc-1hvy7mz-0 gszpcs text-center">
                <p class="Text-st1i2q-0 styled__Description-sc-1hvy7mz-1 haeOQU"> <?php echo e(__("Don't have a")); ?> <?php echo e(App\Models\Setting::find(1)->app_name); ?> <?php echo e(__("account")); ?>?</p>
                <a class="_3Li0AqmO" href="<?php echo e(url('user/register')); ?>"><?php echo e(__('Sign up now')); ?></a>
            </div>
        </form>
    </div>
    <div class="Card-sc-8zkhaa-0 styled__StyledCard-mxvrth-1 fogDtz">
        <p class="Text-st1i2q-0 nWXFK"><?php echo e(__('Become a partner')); ?></p>
        <p class="Text-st1i2q-0 dNmkeH text-center">
            <?php echo e(__('Create your event with')); ?> <?php echo e(\App\Models\Setting::find(1)->app_name); ?> by <br>
            <a href="<?php echo e(url('user/org-register')); ?>" target="_blank" class="Link-sc-2rq62z-0 khXLMG"><?php echo e(__('signing up as a Organizer')); ?></a>
        </p>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/auth/login.blade.php ENDPATH**/ ?>