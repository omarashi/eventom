

<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Edit Roles'),  
        'headerData' => __('Roles') ,
        'url' => 'roles' ,          
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="section-body">
        <div class="row">
            <div class="col-lg-8"><h2 class="section-title"> <?php echo e(__('Edit Roles')); ?></h2></div>           
        </div>       
       
        <div class="row">
            <div class="col-12">
              <div class="card">     
                <div class="card-body">
                    <form method="post" action="<?php echo e(route("roles.update", [$role->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label><?php echo e(__('Name')); ?></label>
                            <input type="text" name="name" value="<?php echo e($role->name); ?>" placeholder="<?php echo e(__('Name')); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" readonly>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Permissions')); ?></label>
                            <select name="permissions[]" class="form-control select2" multiple="multiple">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($per['id']); ?>"
                                    <?php echo e((in_array($per->id, old('permissions', [])) || isset($role) && $role->permissions->contains($per->id)) ? 'selected' : ''); ?>>
                                    <?php echo e($per['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                            
                        </div>
                    </form>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/role/edit.blade.php ENDPATH**/ ?>