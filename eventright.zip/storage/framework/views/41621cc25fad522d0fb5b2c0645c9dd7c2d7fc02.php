

<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Order Detail'),
        'headerData' => __('Orders') ,
        'url' => 'orders' ,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="section-body">
            <div class="invoice">
                <div class="invoice-print">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="invoice-title">
                                <h3><?php echo e(__('Order')); ?> <?php echo e($order->order_id); ?></h3>
                                <div class="invoice-number">
                                    <a class="btn btn-primary" target="_blank"
                                        href="<?php echo e(url('order-invoice-print/' . $order->id)); ?>"><i class="fas fa-download"
                                            id="print_invoice"></i><?php echo e(__('Print')); ?></a>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-6">
                                    <address>
                                        <strong><?php echo e(__('Event')); ?>:</strong>
                                    </address>
                                    <div class="media mb-3">
                                        <img alt="image" class="mr-3"
                                            src="<?php echo e(url('images/upload/' . $order->event->image)); ?>" width="50"
                                            height="50">
                                        <div class="media-body">
                                            <div class="media-title mb-0">
                                                <?php echo e($order->event->name); ?>

                                            </div>
                                            <div class="media-description text-muted">
                                                <?php echo e($order->event->start_time->format('l') . ', ' . $order->event->start_time->format('d M Y')); ?>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6 text-md-right">
                                    <?php if(Auth::user()->hasRole('admin')): ?>
                                        <address>
                                            <strong><?php echo e(__('Organizer')); ?>:</strong><br>
                                            <?php echo e($order->organization->first_name . ' ' . $order->organization->last_name); ?><br>
                                            <?php echo e($order->organization->email); ?><br>
                                            <?php echo e($order->organization->country); ?>

                                        </address>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">

                                    <address>
                                        <strong><?php echo e(__('Attendee')); ?>:</strong><br>
                                        <?php echo e($order->customer->name . ' ' . $order->customer->last_name); ?><br>
                                        <?php echo e($order->customer->email); ?><br>
                                    </address>


                                </div>
                                <div class="col-md-6 text-md-right">
                                    <address>
                                        <strong><?php echo e(__('Order Date')); ?>:</strong><br>
                                        <?php echo e($order->created_at->format('d F, Y')); ?><br><br>
                                    </address>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="section-title"><?php echo e(__('Order Summary')); ?></div>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover table-md">
                                    <tr>
                                        <th>#</th>
                                        <th class="text-center"><?php echo e(__('Ticket Name')); ?></th>
                                        <th class="text-center"><?php echo e(__('Ticket Number')); ?></th>
                                        <th class="text-center"><?php echo e(__('Price')); ?></th>
                                        <th class="text-center"><?php echo e(__('Code')); ?></th>
                                    </tr>
                                    <?php $__currentLoopData = $order->ticket_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td class="text-center"><?php echo e($order->ticket->name); ?></td>
                                            <td class="text-center"><?php echo e($item->ticket_number); ?></td>
                                            <td class="text-center"><?php echo e($currency . $order->ticket->price); ?></td>
                                            <td class="text-center"><a href="<?php echo e(url('get-code/' . $item->id)); ?>"><i
                                                        class="fas fa-print"></i></a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            <div class="row mt-4">
                                <div class="col-lg-8">
                                    <div class="section-title"><?php echo e(__('Payment Method')); ?></div>
                                    <address>
                                        <strong><?php echo e($order->payment_type); ?></strong><br>
                                        <?php if($order->payment_type != 'FREE'): ?>
                                            <span
                                                class="badge mt-1 mb-1 <?php echo e($order->payment_status == 1 ? 'badge-success' : 'badge-warning'); ?>"><?php echo e($order->payment_status == 1 ? 'Paid' : 'waiting'); ?></span><br>
                                            <?php echo e(__('Token:')); ?> <?php echo e($order->payment_token == null ? '-' : $order->payment_token); ?><br>
                                        <?php endif; ?>
                                    </address>
                                </div>
                                <div class="col-lg-4 text-right">
                                    <div class="invoice-detail-item">
                                        <div class="invoice-detail-name"><?php echo e(__('Subtotal')); ?></div>
                                        <div class="invoice-detail-value">
                                            <?php echo e($currency . ($order->payment + $order->coupon_discount - $order->tax)); ?>

                                        </div>
                                    </div>
                                    <div class="invoice-detail-item">
                                        <div class="invoice-detail-name"><?php echo e(__('Coupon Discount')); ?></div>
                                        <div class="invoice-detail-value">(-) <?php echo e($currency . $order->coupon_discount); ?>

                                        </div>
                                    </div>

                                    <?php $__currentLoopData = $order->tax_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="invoice-detail-item">
                                            <div class="invoice-detail-name"><?php echo e($item->taxName); ?></div>
                                            <div class="invoice-detail-value">(+) <?php echo e($currency . $item->price); ?></div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <hr class="mt-2 mb-2">
                                    <div class="invoice-detail-item">
                                        <div class="invoice-detail-name"><?php echo e(__('Total')); ?></div>
                                        <div class="invoice-detail-value invoice-detail-value-lg">
                                            <?php echo e($currency . $order->payment); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/order/invoice.blade.php ENDPATH**/ ?>