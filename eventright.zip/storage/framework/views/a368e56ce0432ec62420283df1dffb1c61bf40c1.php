

<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Setting'),
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="section-body">
            <div class="row">
                <div class="col-lg-8">
                    <h2 class="section-title"> <?php echo e(__('Admin Setting')); ?></h2>
                </div>
                <div class="col-lg-4 text-right">
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <div class="card card-large-icons">
                        <div class="card-icon bg-primary text-white">
                            <i class="fas fa-cog"></i>
                        </div>
                        <div class="card-body">
                            <h4><?php echo e(__('General')); ?></h4>
                            <p><?php echo e(__('General settings such as, site title, site description, logo and so on.')); ?></p>
                            <a href="#general-setting" aria-controls="general-setting" role="button" data-toggle="collapse"
                                class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                    class="fas fa-chevron-right"></i>
                            </a>
                            <div class="collapse mt-3" id="general-setting">
                                <form method="post" action="<?php echo e(url('save-general-setting')); ?>"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group row mb-4">
                                        <label
                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('App Name')); ?></label>
                                        <div class="col-sm-12 col-md-9">
                                            <input type="text" required name="app_name" placeholder="<?php echo e(__('Name')); ?>"
                                                value="<?php echo e($setting->app_name); ?>"
                                                class="form-control <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="form-group row mb-4">
                                            <label
                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Email')); ?></label>
                                            <div class="col-sm-12 col-md-9">
                                                <input type="email" name="email" placeholder="<?php echo e(__('Email')); ?>"
                                                    value="<?php echo e($setting->email); ?>"
                                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="form-group row mb-4">
                                                <label
                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Logo')); ?></label>
                                                <div class="col-sm-12 col-md-9">
                                                    <div id="image-preview" class="image-preview setting-logo-preview"
                                                        style="background-image: url(<?php echo e(url('images/upload/' . $setting->logo)); ?>)">
                                                        <label for="image-upload" id="image-label"> <i
                                                                class="fas fa-plus"></i></label>
                                                        <input type="file" name="logo" id="image-upload" />
                                                    </div>
                                                    <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group row mb-4">
                                                    <label
                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('favicon')); ?></label>
                                                    <div class="col-sm-12 col-md-9">
                                                        <div id="image-preview" class="image-preview setting-favicon-preview"
                                                            style="background-image: url(<?php echo e(url('images/upload/' . $setting->favicon)); ?>)">
                                                            <label for="image-upload" id="image-label"> <i
                                                                    class="fas fa-plus"></i></label>
                                                            <input type="file" name="favicon" id="image-upload" />
                                                        </div>
                                                        <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row mb-4">
                                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                                        <div class="col-sm-12 col-md-7">
                                                            <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="card card-large-icons">
                                        <div class="card-icon bg-primary text-white">
                                            <i class="fas fa-user-secret"></i>
                                        </div>
                                        <div class="card-body">
                                            <h4><?php echo e(__('Organizer Setting')); ?></h4>
                                            <p><?php echo e(__('organizer app settings such as, organizer privacy policy and terms of use.')); ?></p>
                                            <a href="#organization-setting" aria-controls="organization-setting" role="button"
                                                data-toggle="collapse" class="card-cta"
                                                aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i class="fas fa-chevron-right"></i></a>
                                            <div class="collapse mt-3" id="organization-setting">
                                                <form method="post" class="event-form"
                                                    action="<?php echo e(url('save-organization-setting')); ?>">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="form-group">
                                                        <label class="col-form-label "><?php echo e(__('Commission Type')); ?></label>
                                                        <select required name="org_commission_type" class="form-control select2">
                                                            <option value=""><?php echo e(__('Select Commission Type')); ?></option>
                                                            <option value="amount"
                                                                <?php echo e($setting->org_commission_type == 'amount' ? 'selected' : ''); ?>>
                                                                <?php echo e(__('Amount')); ?>

                                                            </option>
                                                            <option value="percentage"
                                                                <?php echo e($setting->org_commission_type == 'percentage' ? 'selected' : ''); ?>>
                                                                <?php echo e(__('Percentage')); ?></option>
                                                        </select>
                                                        <?php $__errorArgs = ['org_commission_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="col-form-label"><?php echo e(__('Organizer Commission')); ?></label>
                                                            <input type="number" name="org_commission" placeholder="<?php echo e(__('Organizer Commission')); ?>"
                                                                value="<?php echo e($setting->org_commission); ?>"
                                                                class="form-control <?php $__errorArgs = ['org_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                            <?php $__errorArgs = ['org_commission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="form-group">
                                                                <label><?php echo e(__('Privacy Policy')); ?></label>
                                                                <textarea name="privacy_policy_organizer" Placeholder="<?php echo e(__('Privacy policy')); ?>"
                                                                    class="textarea_editor <?php $__errorArgs = ['privacy_policy_organizer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                <?php echo e($setting->privacy_policy_organizer); ?>

                                                                                            </textarea>
                                                                <?php $__errorArgs = ['privacy_policy_organizer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label><?php echo e(__('Terms of use')); ?></label>
                                                                    <textarea name="terms_use_organizer" Placeholder="<?php echo e(__('Terms of use')); ?>"
                                                                        class="textarea_editor <?php $__errorArgs = ['terms_use_organizer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                        <?php echo e($setting->terms_use_organizer); ?>

                                                                                                    </textarea>
                                                                    <?php $__errorArgs = ['terms_use_organizer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                                                        <?php endif; ?>
                                                                    </div>


                                                                    <div class="form-group">

                                                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>

                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="card card-large-icons">
                                                        <div class="card-icon bg-primary text-white">
                                                            <i class="fas fa-user-check"></i>
                                                        </div>
                                                        <div class="card-body">
                                                            <h4><?php echo e(__('Verification')); ?></h4>
                                                            <p><?php echo e(__('User Verification settings such as, enable verification and verify user by email or phone.')); ?>

                                                            </p>
                                                            <a href="#verification-setting" aria-controls="verification-setting" role="button"
                                                                data-toggle="collapse" class="card-cta"
                                                                aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i class="fas fa-chevron-right"></i></a>
                                                            <div class="collapse mt-3" id="verification-setting">
                                                                <form method="post" action="<?php echo e(url('save-verification-setting')); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="form-group row mb-4">
                                                                        <label
                                                                            class="col-form-label text-md-right col-12 col-md-4"><?php echo e(__('Enable User Verification')); ?></label>
                                                                        <div class="col-sm-12 col-md-8">
                                                                            <div class="custom-switches-stacked mt-2">
                                                                                <label class="custom-switch pl-0">
                                                                                    <input type="checkbox" name="user_verify"
                                                                                        <?php echo e($setting->user_verify == '1' ? 'checked' : ''); ?> value="1"
                                                                                        class="custom-switch-input">
                                                                                    <span class="custom-switch-indicator"></span>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group row mb-4">
                                                                        <label
                                                                            class="col-form-label text-md-right col-12 col-md-4"><?php echo e(__('Verify by Email')); ?></label>
                                                                        <div class="col-sm-12 col-md-8">
                                                                            <div class="custom-switches-stacked mt-2">
                                                                                <label class="custom-switch pl-0">
                                                                                    <input type="radio" name="verify_by"
                                                                                        <?php echo e($setting->verify_by == 'email' ? 'checked' : ''); ?>

                                                                                        value="email" class="custom-switch-input">
                                                                                    <span class="custom-switch-indicator"></span>
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group row mb-4">
                                                                        <label
                                                                            class="col-form-label text-md-right col-12 col-md-4"><?php echo e(__('Verify by Phone')); ?></label>
                                                                        <div class="col-sm-12 col-md-8">
                                                                            <div class="custom-switches-stacked mt-2">
                                                                                <label class="custom-switch pl-0">
                                                                                    <input type="radio" name="verify_by"
                                                                                        <?php echo e($setting->verify_by == 'phone' ? 'checked' : ''); ?>

                                                                                        value="phone" class="custom-switch-input">
                                                                                    <span class="custom-switch-indicator"></span>
                                                                                </label>
                                                                            </div>
                                                                            <?php $__errorArgs = ['verify_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                <div class="invalid-feedback block"><?php echo e($message); ?></div>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>

                                                                        <div class="form-group row mb-4">
                                                                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                                                            <div class="col-sm-12 col-md-7">
                                                                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                            </div>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="card card-large-icons">
                                                            <div class="card-icon bg-primary text-white">
                                                                <i class="fas fa-hand-holding-usd"></i>
                                                            </div>
                                                            <div class="card-body">
                                                                <h4><?php echo e(__('Payment Setting')); ?></h4>
                                                                <p><?php echo e(__('Payment settings include different payment gateway and which will display on app.')); ?>

                                                                </p>
                                                                <a href="#payment-setting" aria-controls="payment-setting" role="button" data-toggle="collapse"
                                                                    class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                                                        class="fas fa-chevron-right"></i></a>
                                                                <div class="collapse mt-3" id="payment-setting">
                                                                    <form method="post" action="<?php echo e(url('save-payment-setting')); ?>">
                                                                        <?php echo csrf_field(); ?>
                                                                        <div class="form-group row mb-4">
                                                                            <label
                                                                                class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Cash on Delivery')); ?></label>
                                                                            <div class="col-sm-12 col-md-9">
                                                                                <div class="custom-switches-stacked mt-2">
                                                                                    <label class="custom-switch pl-0">
                                                                                        <input type="checkbox" name="cod"
                                                                                            <?php echo e($payment->cod == '1' ? 'checked' : ''); ?> value="1"
                                                                                            class="custom-switch-input">
                                                                                        <span class="custom-switch-indicator"></span>
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group row mb-4">
                                                                            <label
                                                                                class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Stripe')); ?></label>
                                                                            <div class="col-sm-12 col-md-9">
                                                                                <div class="custom-switches-stacked mt-2">
                                                                                    <label class="custom-switch pl-0">
                                                                                        <input type="checkbox" name="stripe"
                                                                                            <?php echo e($payment->stripe == '1' ? 'checked' : ''); ?> value="1"
                                                                                            class="custom-switch-input">
                                                                                        <span class="custom-switch-indicator"></span>
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group row mb-4">
                                                                            <label
                                                                                class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Paypal')); ?></label>
                                                                            <div class="col-sm-12 col-md-9">
                                                                                <div class="custom-switches-stacked mt-2">
                                                                                    <label class="custom-switch pl-0">
                                                                                        <input type="checkbox" name="paypal"
                                                                                            <?php echo e($payment->paypal == '1' ? 'checked' : ''); ?> value="1"
                                                                                            class="custom-switch-input">
                                                                                        <span class="custom-switch-indicator"></span>
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group row mb-4">
                                                                            <label
                                                                                class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Flutterwave')); ?></label>
                                                                            <div class="col-sm-12 col-md-9">
                                                                                <div class="custom-switches-stacked mt-2">
                                                                                    <label class="custom-switch pl-0">
                                                                                        <input type="checkbox" name="flutterwave"
                                                                                            <?php echo e($payment->flutterwave == '1' ? 'checked' : ''); ?> value="1"
                                                                                            class="custom-switch-input">
                                                                                        <span class="custom-switch-indicator"></span>
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group row mb-4">
                                                                            <label
                                                                                class="col-form-label text-md-right col-12 col-md-3"><?php echo e(__('Razorpay')); ?></label>
                                                                            <div class="col-sm-12 col-md-9">
                                                                                <div class="custom-switches-stacked mt-2">
                                                                                    <label class="custom-switch pl-0">
                                                                                        <input type="checkbox" name="razor"
                                                                                            <?php echo e($payment->razor == '1' ? 'checked' : ''); ?> value="1"
                                                                                            class="custom-switch-input">
                                                                                        <span class="custom-switch-indicator"></span>
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group row mb-4">
                                                                            <label
                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Stripe secret key')); ?></label>
                                                                            <div class="col-sm-12 col-md-9">
                                                                                <input type="text" name="stripeSecretKey" placeholder="<?php echo e(__('Stripe secret key')); ?>"
                                                                                    value="<?php echo e($payment->stripeSecretKey); ?>"
                                                                                    class="form-control <?php $__errorArgs = ['stripeSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                <?php $__errorArgs = ['stripeSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                            </div>
                                                                            <div class="form-group row mb-4">
                                                                                <label
                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Stripe public key')); ?></label>
                                                                                <div class="col-sm-12 col-md-9">
                                                                                    <input type="text" name="stripePublicKey" placeholder="<?php echo e(__('Stripe public key')); ?>"
                                                                                        value="<?php echo e($payment->stripePublicKey); ?>"
                                                                                        class="form-control <?php $__errorArgs = ['stripePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                    <?php $__errorArgs = ['stripePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="form-group row mb-4">
                                                                                    <label
                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Paypal Client ID')); ?></label>
                                                                                    <div class="col-sm-12 col-md-9">
                                                                                        <input type="text" name="paypalClientId" placeholder="<?php echo e(__('Paypal Client ID')); ?>"
                                                                                            value="<?php echo e($payment->paypalClientId); ?>"
                                                                                            class="form-control <?php $__errorArgs = ['paypalClientId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                        <?php $__errorArgs = ['paypalClientId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                            <?php endif; ?>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="form-group row mb-4">
                                                                                        <label
                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Paypal Secret key')); ?></label>
                                                                                        <div class="col-sm-12 col-md-9">
                                                                                            <input type="text" name="paypalSecret" placeholder="<?php echo e(__('Paypal Secret key')); ?>"
                                                                                                value="<?php echo e($payment->paypalSecret); ?>"
                                                                                                class="form-control <?php $__errorArgs = ['paypalSecret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                            <?php $__errorArgs = ['paypalSecret'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                <?php endif; ?>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="form-group row mb-4">
                                                                                            <label
                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Razorpay Publish key')); ?></label>
                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                <input type="text" name="razorPublishKey" placeholder="<?php echo e(__('Razorpay Publish key')); ?>"
                                                                                                    value="<?php echo e($payment->razorPublishKey); ?>"
                                                                                                    class="form-control <?php $__errorArgs = ['razorPublishKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                <?php $__errorArgs = ['razorPublishKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                    <?php endif; ?>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="form-group row mb-4">
                                                                                                <label
                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Razorpay Secret key')); ?></label>
                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                    <input type="text" name="razorSecretKey" placeholder="<?php echo e(__('Razorpay Secret key')); ?>"
                                                                                                        value="<?php echo e($payment->razorSecretKey); ?>"
                                                                                                        class="form-control <?php $__errorArgs = ['razorSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                    <?php $__errorArgs = ['razorSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                        <?php endif; ?>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="form-group row mb-4">
                                                                                                    <label
                                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Flutterwave public key')); ?></label>
                                                                                                    <div class="col-sm-12 col-md-9">
                                                                                                        <input type="text" name="ravePublicKey" placeholder="<?php echo e(__('Flutterwave public key')); ?>"
                                                                                                            value="<?php echo e($payment->ravePublicKey); ?>"
                                                                                                            class="form-control <?php $__errorArgs = ['ravePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                        <?php $__errorArgs = ['ravePublicKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="form-group row mb-4">
                                                                                                        <label
                                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Flutterwave secret key')); ?></label>
                                                                                                        <div class="col-sm-12 col-md-9">
                                                                                                            <input type="text" name="raveSecretKey" placeholder="<?php echo e(__('Flutterwave secret key')); ?>"
                                                                                                                value="<?php echo e($payment->raveSecretKey); ?>"
                                                                                                                class="form-control <?php $__errorArgs = ['raveSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                            <?php $__errorArgs = ['raveSecretKey'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                <?php endif; ?>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="form-group row mb-4">
                                                                                                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                                                                                            <div class="col-sm-12 col-md-7">
                                                                                                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </form>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col-lg-6">
                                                                                        <div class="card card-large-icons">
                                                                                            <div class="card-icon bg-primary text-white">
                                                                                                <i class="fas fa-envelope"></i>
                                                                                            </div>
                                                                                            <div class="card-body">
                                                                                                <h4><?php echo e(__('Mail Notification')); ?></h4>
                                                                                                <p><?php echo e(__('Email SMTP configuration settings and email notifications related to email.')); ?>

                                                                                                </p>
                                                                                                <a href="#mail-setting" aria-controls="mail-setting" role="button" data-toggle="collapse"
                                                                                                    class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                                                                                        class="fas fa-chevron-right"></i></a>
                                                                                                <div class="collapse mt-3" id="mail-setting">
                                                                                                    <form method="post" action="<?php echo e(url('save-mail-setting')); ?>">
                                                                                                        <?php echo csrf_field(); ?>
                                                                                                        <div class="form-group row mb-4">
                                                                                                            <label
                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enable Notification')); ?></label>
                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                <div class="custom-switches-stacked mt-2">
                                                                                                                    <label class="custom-switch pl-0">
                                                                                                                        <input type="checkbox" name="mail_notification"
                                                                                                                            <?php echo e($setting->mail_notification == '1' ? 'checked' : ''); ?>

                                                                                                                            value="1" class="custom-switch-input">
                                                                                                                        <span class="custom-switch-indicator"></span>
                                                                                                                    </label>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="form-group row mb-4">
                                                                                                            <label
                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Host')); ?></label>
                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                <input type="text" name="mail_host" placeholder="<?php echo e(__('Mail Host')); ?>"
                                                                                                                    value="<?php echo e($setting->mail_host); ?>"
                                                                                                                    class="form-control <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                <?php $__errorArgs = ['mail_host'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                    <?php endif; ?>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                            <div class="form-group row mb-4">
                                                                                                                <label
                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Port')); ?></label>
                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                    <input type="number" name="mail_port" placeholder="<?php echo e(__('Mail Port')); ?>"
                                                                                                                        value="<?php echo e($setting->mail_port); ?>"
                                                                                                                        class="form-control <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                    <?php $__errorArgs = ['mail_port'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                        <?php endif; ?>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                                <div class="form-group row mb-4">
                                                                                                                    <label
                                                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Username')); ?></label>
                                                                                                                    <div class="col-sm-12 col-md-9">
                                                                                                                        <input type="email" name="mail_username" placeholder="<?php echo e(__('Mail Username')); ?>"
                                                                                                                            value="<?php echo e($setting->mail_username); ?>"
                                                                                                                            class="form-control <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                        <?php $__errorArgs = ['mail_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                            <?php endif; ?>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                    <div class="form-group row mb-4">
                                                                                                                        <label
                                                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Password')); ?></label>
                                                                                                                        <div class="col-sm-12 col-md-9">
                                                                                                                            <input type="password" name="mail_password" placeholder="<?php echo e(__('Mail Password')); ?>"
                                                                                                                                value="<?php echo e($setting->mail_password); ?>"
                                                                                                                                class="form-control <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                            <?php $__errorArgs = ['mail_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                <?php endif; ?>
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                        <div class="form-group row mb-4">
                                                                                                                            <label
                                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Mail Sender Email')); ?></label>
                                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                                <input type="email" name="sender_email" placeholder="<?php echo e(__('Mail Sender Email')); ?>"
                                                                                                                                    value="<?php echo e($setting->sender_email); ?>"
                                                                                                                                    class="form-control <?php $__errorArgs = ['sender_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                <?php $__errorArgs = ['sender_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                    <?php endif; ?>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                                                                                                                <div class="col-sm-12 col-md-7">
                                                                                                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                        </form>
                                                                                                                    </div>

                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="col-lg-6">
                                                                                                            <div class="card card-large-icons">
                                                                                                                <div class="card-icon bg-primary text-white">
                                                                                                                    <i class="fas fa-bell"></i>
                                                                                                                </div>
                                                                                                                <div class="card-body">
                                                                                                                    <h4><?php echo e(__('Push Notification')); ?></h4>
                                                                                                                    <p><?php echo e(__('OneSignal configuration settings and app push notifications setting.')); ?></p>
                                                                                                                    <a href="#push-notification-setting" aria-controls="push-notification-setting" role="button"
                                                                                                                        data-toggle="collapse" class="card-cta"
                                                                                                                        aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                                                                                                            class="fas fa-chevron-right"></i></a>
                                                                                                                    <div class="collapse mt-3" id="push-notification-setting">
                                                                                                                        <form method="post" action="<?php echo e(url('save-pushNotification-setting')); ?>">
                                                                                                                            <?php echo csrf_field(); ?>
                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                <label
                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enable Notification')); ?></label>
                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                    <div class="custom-switches-stacked mt-2">
                                                                                                                                        <label class="custom-switch pl-0">
                                                                                                                                            <input type="checkbox" name="push_notification"
                                                                                                                                                <?php echo e($setting->push_notification == '1' ? 'checked' : ''); ?>

                                                                                                                                                value="1" class="custom-switch-input">
                                                                                                                                            <span class="custom-switch-indicator"></span>
                                                                                                                                        </label>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                            </div>
                                                                                                                            <p><?php echo e(__('OneSignal configuration for user app:')); ?></p>
                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                <label
                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal App Id')); ?></label>
                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                    <input type="text" name="onesignal_app_id" placeholder="<?php echo e(__('OneSignal App Id')); ?>"
                                                                                                                                        value="<?php echo e($setting->onesignal_app_id); ?>"
                                                                                                                                        class="form-control <?php $__errorArgs = ['onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                    <?php $__errorArgs = ['onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                        <?php endif; ?>
                                                                                                                                    </div>
                                                                                                                                </div>
                                                                                                                                <div class="form-group row mb-4">
                                                                                                                                    <label
                                                                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Project Number')); ?></label>
                                                                                                                                    <div class="col-sm-12 col-md-9">
                                                                                                                                        <input type="text" name="onesignal_project_number"
                                                                                                                                            placeholder="<?php echo e(__('Onesignal Project Number')); ?>"
                                                                                                                                            value="<?php echo e($setting->onesignal_project_number); ?>"
                                                                                                                                            class="form-control <?php $__errorArgs = ['onesignal_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                        <?php $__errorArgs = ['onesignal_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                            <?php endif; ?>
                                                                                                                                        </div>
                                                                                                                                    </div>
                                                                                                                                    <div class="form-group row mb-4">
                                                                                                                                        <label
                                                                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Api key')); ?></label>
                                                                                                                                        <div class="col-sm-12 col-md-9">
                                                                                                                                            <input type="text" name="onesignal_api_key" placeholder="<?php echo e(__('Onesignal Api key')); ?>"
                                                                                                                                                value="<?php echo e($setting->onesignal_api_key); ?>"
                                                                                                                                                class="form-control <?php $__errorArgs = ['onesignal_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                            <?php $__errorArgs = ['onesignal_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                <?php endif; ?>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                        <div class="form-group row mb-4">
                                                                                                                                            <label
                                                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Auth Key')); ?></label>
                                                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                                                <input type="text" name="onesignal_auth_key" placeholder="<?php echo e(__('Onesignal Auth Key')); ?>"
                                                                                                                                                    value="<?php echo e($setting->onesignal_auth_key); ?>"
                                                                                                                                                    class="form-control <?php $__errorArgs = ['onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                <?php $__errorArgs = ['onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                    <?php endif; ?>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                            <p><?php echo e(__('OneSignal configuration for organizer app:')); ?></p>
                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                <label
                                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal App Id')); ?></label>
                                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                                    <input type="text" name="or_onesignal_app_id" placeholder="<?php echo e(__('OneSignal App Id')); ?>"
                                                                                                                                                        value="<?php echo e($setting->or_onesignal_app_id); ?>"
                                                                                                                                                        class="form-control <?php $__errorArgs = ['or_onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                    <?php $__errorArgs = ['or_onesignal_app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                        <?php endif; ?>
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                                <div class="form-group row mb-4">
                                                                                                                                                    <label
                                                                                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Project Number')); ?></label>
                                                                                                                                                    <div class="col-sm-12 col-md-9">
                                                                                                                                                        <input type="text" name="or_onesignal_project_number"
                                                                                                                                                            placeholder="<?php echo e(__('Onesignal Project Number')); ?>"
                                                                                                                                                            value="<?php echo e($setting->or_onesignal_project_number); ?>"
                                                                                                                                                            class="form-control <?php $__errorArgs = ['or_onesignal_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                        <?php $__errorArgs = ['or_onesignal_project_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                            <?php endif; ?>
                                                                                                                                                        </div>
                                                                                                                                                    </div>
                                                                                                                                                    <div class="form-group row mb-4">
                                                                                                                                                        <label
                                                                                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Api key')); ?></label>
                                                                                                                                                        <div class="col-sm-12 col-md-9">
                                                                                                                                                            <input type="text" name="or_onesignal_api_key" placeholder="<?php echo e(__('Onesignal Api key')); ?>"
                                                                                                                                                                value="<?php echo e($setting->or_onesignal_api_key); ?>"
                                                                                                                                                                class="form-control <?php $__errorArgs = ['or_onesignal_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                            <?php $__errorArgs = ['or_onesignal_api_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                <?php endif; ?>
                                                                                                                                                            </div>
                                                                                                                                                        </div>

                                                                                                                                                        <div class="form-group row mb-4">
                                                                                                                                                            <label
                                                                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Onesignal Auth Key')); ?></label>
                                                                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                                                                <input type="text" name="or_onesignal_auth_key" placeholder="<?php echo e(__('Onesignal Auth Key')); ?>"
                                                                                                                                                                    value="<?php echo e($setting->or_onesignal_auth_key); ?>"
                                                                                                                                                                    class="form-control <?php $__errorArgs = ['or_onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                <?php $__errorArgs = ['or_onesignal_auth_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                    <?php endif; ?>
                                                                                                                                                                </div>
                                                                                                                                                            </div>

                                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                                                                                                                                                <div class="col-sm-12 col-md-7">
                                                                                                                                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                                                                                                                </div>
                                                                                                                                                            </div>
                                                                                                                                                        </form>
                                                                                                                                                    </div>
                                                                                                                                                </div>
                                                                                                                                            </div>
                                                                                                                                        </div>
                                                                                                                                        <div class="col-lg-6">
                                                                                                                                            <div class="card card-large-icons">
                                                                                                                                                <div class="card-icon bg-primary text-white">
                                                                                                                                                    <i class="fas fa-sms"></i>
                                                                                                                                                </div>
                                                                                                                                                <div class="card-body">
                                                                                                                                                    <h4><?php echo e(__('SMS Notification')); ?></h4>
                                                                                                                                                    <p><?php echo e(__('SMS configuration settings of twillio SMS gateway.')); ?></p>
                                                                                                                                                    <a href="#push-sms-setting" aria-controls="push-sms-setting" role="button"
                                                                                                                                                        data-toggle="collapse" class="card-cta"
                                                                                                                                                        aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                                                                                                                                            class="fas fa-chevron-right"></i></a>
                                                                                                                                                    <div class="collapse mt-3" id="push-sms-setting">
                                                                                                                                                        <form method="post" action="<?php echo e(url('save-sms-setting')); ?>">
                                                                                                                                                            <?php echo csrf_field(); ?>
                                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                                <label
                                                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Enable SMS Notification')); ?></label>
                                                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                                                    <div class="custom-switches-stacked mt-2">
                                                                                                                                                                        <label class="custom-switch pl-0">
                                                                                                                                                                            <input type="checkbox" name="sms_notification"
                                                                                                                                                                                <?php echo e($setting->sms_notification == '1' ? 'checked' : ''); ?>

                                                                                                                                                                                value="1" class="custom-switch-input">
                                                                                                                                                                            <span class="custom-switch-indicator"></span>
                                                                                                                                                                        </label>
                                                                                                                                                                    </div>
                                                                                                                                                                </div>
                                                                                                                                                            </div>
                                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                                <label
                                                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Twilio Account ID')); ?></label>
                                                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                                                    <input type="text" name="twilio_account_id" placeholder="<?php echo e(__('Twilio Account ID')); ?>"
                                                                                                                                                                        value="<?php echo e($setting->twilio_account_id); ?>"
                                                                                                                                                                        class="form-control <?php $__errorArgs = ['twilio_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                    <?php $__errorArgs = ['twilio_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                        <?php endif; ?>
                                                                                                                                                                    </div>
                                                                                                                                                                </div>
                                                                                                                                                                <div class="form-group row mb-4">
                                                                                                                                                                    <label
                                                                                                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Twilio auth token')); ?></label>
                                                                                                                                                                    <div class="col-sm-12 col-md-9">
                                                                                                                                                                        <input type="text" name="twilio_auth_token" placeholder="<?php echo e(__('Twilio auth token')); ?>"
                                                                                                                                                                            value="<?php echo e($setting->twilio_auth_token); ?>"
                                                                                                                                                                            class="form-control <?php $__errorArgs = ['twilio_auth_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                        <?php $__errorArgs = ['twilio_auth_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                            <?php endif; ?>
                                                                                                                                                                        </div>
                                                                                                                                                                    </div>
                                                                                                                                                                    <div class="form-group row mb-4">
                                                                                                                                                                        <label
                                                                                                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Twilio phone number')); ?></label>
                                                                                                                                                                        <div class="col-sm-12 col-md-9">
                                                                                                                                                                            <input type="text" name="twilio_phone_number" placeholder="<?php echo e(__('Twilio phone number')); ?>"
                                                                                                                                                                                value="<?php echo e($setting->twilio_phone_number); ?>"
                                                                                                                                                                                class="form-control <?php $__errorArgs = ['twilio_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                            <?php $__errorArgs = ['twilio_phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                <?php endif; ?>
                                                                                                                                                                            </div>
                                                                                                                                                                        </div>
                                                                                                                                                                        <div class="form-group row mb-4">
                                                                                                                                                                            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                                                                                                                                                            <div class="col-sm-12 col-md-7">
                                                                                                                                                                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                                                                                                                            </div>
                                                                                                                                                                        </div>
                                                                                                                                                                    </form>
                                                                                                                                                                </div>
                                                                                                                                                            </div>
                                                                                                                                                        </div>
                                                                                                                                                    </div>
                                                                                                                                                    <div class="col-lg-6">
                                                                                                                                                        <div class="card card-large-icons">
                                                                                                                                                            <div class="card-icon bg-primary text-white">
                                                                                                                                                                <i class="fas fa-tools"></i>
                                                                                                                                                            </div>
                                                                                                                                                            <div class="card-body">
                                                                                                                                                                <h4><?php echo e(__('Additional Setting')); ?></h4>
                                                                                                                                                                <p><?php echo e(__('General setting such as currency, map key, default map coordinates and so on.')); ?>

                                                                                                                                                                </p>
                                                                                                                                                                <a href="#additional-setting" aria-controls="additional-setting" role="button"
                                                                                                                                                                    data-toggle="collapse" class="card-cta"
                                                                                                                                                                    aria-expanded="false"><?php echo e(__('Change Setting')); ?> <i
                                                                                                                                                                        class="fas fa-chevron-right"></i></a>
                                                                                                                                                                <div class="collapse mt-3" id="additional-setting">
                                                                                                                                                                    <form method="post" action="<?php echo e(url('additional-setting')); ?>">
                                                                                                                                                                        <?php echo csrf_field(); ?>
                                                                                                                                                                        <div class="form-group row mb-4">
                                                                                                                                                                            <label
                                                                                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Currency')); ?></label>
                                                                                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                                                                                <select required name="currency" class="form-control select2">
                                                                                                                                                                                    <option value=""><?php echo e(__('Select default currency')); ?></option>
                                                                                                                                                                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                                                                                        <option value="<?php echo e($item->code); ?>"
                                                                                                                                                                                            <?php echo e($setting->currency == $item->code ? 'Selected' : ''); ?>>
                                                                                                                                                                                            <?php echo e($item->currency . ' ( ' . $item->symbol . '- ' . $item->code . ')'); ?>

                                                                                                                                                                                        </option>
                                                                                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                                                                                </select>
                                                                                                                                                                                <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                    <?php endif; ?>
                                                                                                                                                                                </div>
                                                                                                                                                                            </div>
                                                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                                                <label
                                                                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('TimeZone')); ?></label>
                                                                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                                                                    <select required name="timezone" class="form-control select2">
                                                                                                                                                                                        <option value=""><?php echo e(__('Select default Timezone')); ?></option>
                                                                                                                                                                                        <?php $__currentLoopData = $timezone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                                                                                            <option value="<?php echo e($item->TimeZone); ?>"
                                                                                                                                                                                                <?php echo e($setting->timezone == $item->TimeZone ? 'Selected' : ''); ?>>
                                                                                                                                                                                                <?php echo e($item->TimeZone); ?></option>
                                                                                                                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                                                                                    </select>
                                                                                                                                                                                    <?php $__errorArgs = ['timezone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                        <?php endif; ?>
                                                                                                                                                                                    </div>
                                                                                                                                                                                </div>
                                                                                                                                                                                <div class="form-group row mb-4">
                                                                                                                                                                                    <label
                                                                                                                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Language')); ?></label>
                                                                                                                                                                                    <div class="col-sm-12 col-md-9">
                                                                                                                                                                                        <select required name="language" class="form-control select2">
                                                                                                                                                                                            <option value=""><?php echo e(__('Select default Language')); ?></option>
                                                                                                                                                                                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                                                                                                <option value="<?php echo e($language->name); ?>"
                                                                                                                                                                                                    <?php echo e($language->name == $setting->language ? 'Selected' : ''); ?>>
                                                                                                                                                                                                    <?php echo e($language->name); ?></option>
                                                                                                                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                                                                                        </select>
                                                                                                                                                                                        <?php $__errorArgs = ['language'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                            <?php endif; ?>
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>
                                                                                                                                                                                    <div class="form-group row mb-4">
                                                                                                                                                                                        <label
                                                                                                                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('App Version')); ?></label>
                                                                                                                                                                                        <div class="col-sm-12 col-md-9">
                                                                                                                                                                                            <input type="text" required name="app_version" placeholder="<?php echo e(__('App Version')); ?>"
                                                                                                                                                                                                value="<?php echo e($setting->app_version); ?>"
                                                                                                                                                                                                class="form-control <?php $__errorArgs = ['app_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                            <?php $__errorArgs = ['app_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                <?php endif; ?>
                                                                                                                                                                                            </div>
                                                                                                                                                                                        </div>
                                                                                                                                                                                        <div class="form-group row mb-4">
                                                                                                                                                                                            <label
                                                                                                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('CopyRight content')); ?></label>
                                                                                                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                <input type="text" required name="footer_copyright"
                                                                                                                                                                                                    placeholder="<?php echo e(__('Footer CopyRight Content')); ?>"
                                                                                                                                                                                                    value="<?php echo e($setting->footer_copyright); ?>"
                                                                                                                                                                                                    class="form-control <?php $__errorArgs = ['footer_copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                <?php $__errorArgs = ['footer_copyright'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                    <?php endif; ?>
                                                                                                                                                                                                </div>
                                                                                                                                                                                            </div>
                                                                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                                                                <label
                                                                                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Map key')); ?></label>
                                                                                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                    <input type="text" name="map_key" placeholder="<?php echo e(__('Map key')); ?>"
                                                                                                                                                                                                        value="<?php echo e($setting->map_key); ?>"
                                                                                                                                                                                                        class="form-control <?php $__errorArgs = ['map_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                    <?php $__errorArgs = ['map_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                        <?php endif; ?>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                </div>
                                                                                                                                                                                                <div class="form-group row mb-4">
                                                                                                                                                                                                    <label
                                                                                                                                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Default Latitude')); ?></label>
                                                                                                                                                                                                    <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                        <input type="text" required name="default_lat" placeholder="<?php echo e(__('Default Latitude')); ?>"
                                                                                                                                                                                                            value="<?php echo e($setting->default_lat); ?>"
                                                                                                                                                                                                            class="form-control <?php $__errorArgs = ['default_lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                        <?php $__errorArgs = ['default_lat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                            <?php endif; ?>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                    <div class="form-group row mb-4">
                                                                                                                                                                                                        <label
                                                                                                                                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Default Longitude')); ?></label>
                                                                                                                                                                                                        <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                            <input type="text" required name="default_long" placeholder="<?php echo e(__('Default Longitude')); ?>"
                                                                                                                                                                                                                value="<?php echo e($setting->default_long); ?>"
                                                                                                                                                                                                                class="form-control <?php $__errorArgs = ['default_long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                            <?php $__errorArgs = ['default_long'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                                <?php endif; ?>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                        <div class="form-group row mb-4">
                                                                                                                                                                                                            <label
                                                                                                                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Primary Color')); ?></label>
                                                                                                                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                                <div class="input-group colorpickerinput">
                                                                                                                                                                                                                    <input type="text" name="primary_color"
                                                                                                                                                                                                                        value="<?php echo e($setting->primary_color); ?>" placeholder="<?php echo e(__('Choose color')); ?>"
                                                                                                                                                                                                                        class="form-control  <?php $__errorArgs = ['primary_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                                    <div class="input-group-append">
                                                                                                                                                                                                                        <div class="input-group-text color-input">
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                <?php $__errorArgs = ['primary_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                                    <?php endif; ?>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                                                                                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                                                                                                                                                                                                <div class="col-sm-12 col-md-7">
                                                                                                                                                                                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                        </form>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                </div>
                                                                                                                                                                                            </div>
                                                                                                                                                                                        </div>
                                                                                                                                                                                        <div class="col-lg-6">
                                                                                                                                                                                            <div class="card card-large-icons">
                                                                                                                                                                                                <div class="card-icon bg-primary text-white">
                                                                                                                                                                                                    <i class="fas fa-info-circle"></i>
                                                                                                                                                                                                </div>
                                                                                                                                                                                                <div class="card-body">
                                                                                                                                                                                                    <h4><?php echo e(__('Support Setting')); ?></h4>
                                                                                                                                                                                                    <p><?php echo e(__('Support setting include links of pages like Privacy policy, Terms of services, Help center and so on.')); ?>

                                                                                                                                                                                                    </p>
                                                                                                                                                                                                    <a href="#support-setting" aria-controls="support-setting" role="button" data-toggle="collapse"
                                                                                                                                                                                                        class="card-cta" aria-expanded="false"><?php echo e(__('Change Setting')); ?><i
                                                                                                                                                                                                            class="fas fa-chevron-right"></i></a>
                                                                                                                                                                                                    <div class="collapse mt-3" id="support-setting">
                                                                                                                                                                                                        <form method="post" action="<?php echo e(url('support-setting')); ?>">
                                                                                                                                                                                                            <?php echo csrf_field(); ?>
                                                                                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                                                                                <label
                                                                                                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Help Center')); ?></label>
                                                                                                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                                    <input type="url" required name="help_center" placeholder="<?php echo e(__('Help Center url')); ?>"
                                                                                                                                                                                                                        value="<?php echo e($setting->help_center); ?>"
                                                                                                                                                                                                                        class="form-control <?php $__errorArgs = ['help_center'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                                    <?php $__errorArgs = ['help_center'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                                        <?php endif; ?>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                <div class="form-group row mb-4">
                                                                                                                                                                                                                    <label
                                                                                                                                                                                                                        class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Privacy policy')); ?></label>
                                                                                                                                                                                                                    <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                                        <input type="url" required name="privacy_policy"
                                                                                                                                                                                                                            placeholder="<?php echo e(__('Privacy policy url')); ?>" value="<?php echo e($setting->privacy_policy); ?>"
                                                                                                                                                                                                                            class="form-control <?php $__errorArgs = ['privacy_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                                        <?php $__errorArgs = ['privacy_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                                            <?php endif; ?>
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                    <div class="form-group row mb-4">
                                                                                                                                                                                                                        <label
                                                                                                                                                                                                                            class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Cookie policy')); ?></label>
                                                                                                                                                                                                                        <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                                            <input type="url" name="cookie_policy" placeholder="<?php echo e(__('Cookie policy url')); ?>"
                                                                                                                                                                                                                                value="<?php echo e($setting->cookie_policy); ?>"
                                                                                                                                                                                                                                class="form-control <?php $__errorArgs = ['cookie_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                                            <?php $__errorArgs = ['cookie_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                                                <?php endif; ?>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                        <div class="form-group row mb-4">
                                                                                                                                                                                                                            <label
                                                                                                                                                                                                                                class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Cookie policy')); ?></label>
                                                                                                                                                                                                                            <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                                                <input type="url" name="terms_services" placeholder="<?php echo e(__('Cookie policy url')); ?>"
                                                                                                                                                                                                                                    value="<?php echo e($setting->terms_services); ?>"
                                                                                                                                                                                                                                    class="form-control <?php $__errorArgs = ['terms_services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                                                <?php $__errorArgs = ['terms_services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                                                    <?php endif; ?>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                            <div class="form-group row mb-4">
                                                                                                                                                                                                                                <label
                                                                                                                                                                                                                                    class="col-form-label text-md-right col-12 col-md-3 col-lg-3"><?php echo e(__('Acknowledgement')); ?></label>
                                                                                                                                                                                                                                <div class="col-sm-12 col-md-9">
                                                                                                                                                                                                                                    <input type="url" name="acknowledgement" placeholder="<?php echo e(__('Acknowledgement page url')); ?>"
                                                                                                                                                                                                                                        value="<?php echo e($setting->acknowledgement); ?>"
                                                                                                                                                                                                                                        class="form-control <?php $__errorArgs = ['acknowledgement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                                                                                                                                                                                                    <?php $__errorArgs = ['acknowledgement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                                                                                                                                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                                                                                                                                                                                        <?php endif; ?>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                                <div class="form-group row mb-4">
                                                                                                                                                                                                                                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                                                                                                                                                                                                                                    <div class="col-sm-12 col-md-7">
                                                                                                                                                                                                                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                                </div>
                                                                                                                                                                                                                            </form>
                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                    </div>
                                                                                                                                                                                                                </div>
                                                                                                                                                                                                            </div>
                                                                                                                                                                                                        </div>
                                                                                                                                                                                                    </div>
                                                                                                                                                                                                </section>
                                                                                                                                                                                            <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/setting.blade.php ENDPATH**/ ?>