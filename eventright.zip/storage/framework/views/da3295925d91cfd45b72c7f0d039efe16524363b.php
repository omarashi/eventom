<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.layout.breadcrumbs', [
        'title' => $data->name,
        'page' => __('Event Detail'),
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <section class="property-single nav-arrow-b">
    <div class="container">
      <div class="row">
          <div class="col-lg-12">
            <?php if(session('status')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <?php echo e(session('status')); ?>

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>
              </div>
            <?php endif; ?>
          </div>
          <div class="col-lg-12 col-md-12 col-sm-12" >
            <div id="property-single-carousel" class="owl-carousel owl-arrow gallery-property">
                <div class="carousel-item-b">
                  <img src="<?php echo e(url('images/upload/'.$data->image)); ?>" alt="">
                </div>
                <?php $__currentLoopData = explode(',',$data->gallery); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item-b">
                        <img src="<?php echo e(url('images/upload/'.$item)); ?>" alt="">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
          </div>

        <div class="col-sm-12">
            <div class="row justify-content-between">
                <div class="col-lg-7">
                    <div class="title-box-d">
                        <h3 class="title-d"><?php echo e($data->name); ?></h3>
                        <p class="mb-0"><?php echo e(__('By')); ?>: <a href="<?php echo e(url('organization/'.$data->organization->id.'/'.$data->organization->first_name.'-'.$data->organization->last_name)); ?>"><?php echo e($data->organization->first_name.' '.$data->organization->last_name); ?></a></p>
                    </div>
                    <div class="rating mb-2">
                       <?php for($i = 1; $i <= 5; $i++): ?>
                          <i class="fa fa-star <?php echo e($data->rate>=$i?'active':''); ?>"></i>
                       <?php endfor; ?>
                    </div>
                    <div class="property-description">
                        <p class="description color-text-a mb-4">
                            <?php echo $data->description; ?>

                        </p>
                        <ul class="tags">
                            <?php if($data->type=="online"): ?>
                            <li><a href="javascript:void(0)" class="tag"><?php echo e(__('Online event')); ?></a></li>
                            <?php endif; ?>
                            <li><a href="javascript:void(0)" class="tag"><?php echo e($data->category->name); ?></a></li>
                            <?php $__currentLoopData = array_filter(explode(',',$data->tags)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="javascript:void(0)" class="tag"><?php echo e($item); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="property-summary">

                        <div class="summary-list">
                          <div class="summery-top">
                            <span class="event-date-time"><?php echo e($data->start_time->format('l').', '.$data->start_time->format('M d, Y h:i a').'  to'); ?> </span>
                            <span class="event-date-time"><?php echo e($data->end_time->format('l').', '.$data->end_time->format('M d, Y h:i a')); ?> </span>

                            <span class="event-date-time">
                              <?php if($data->type=="online"): ?>
                              <?php echo e(__('Online Event')); ?>

                              <?php else: ?>
                                <i class="fa fa-map-marker text-primary pr-2"></i><?php echo e($data->address); ?>

                              <?php endif; ?>
                            </span>
                            <p class="mt-2"><i class="fa fa-users pr-2 text-primary "></i><?php echo e($data->people .' People'); ?></p>
                          </div>
                          <div class="summery-org mt-4">
                            <h4 class="mb-4"> <?php echo e(__('Organised by')); ?></h4>
                            <div class="row">
                              <div class="col-3">
                                <img  class="org-img" src="<?php echo e(url('images/upload/'.$data->organization->image)); ?>">
                              </div>
                              <div class="col-9">
                                <p class="mb-0"><?php echo e($data->organization->first_name.' '.$data->organization->last_name); ?></p>
                                <p><?php echo e($data->organization->name.' Organization'); ?></p>

                              </div>
                              <div class="col-12 mt-3">
                                <span><?php echo e($data->organization->bio); ?></span>
                                <button class="btn d-block pl-0 mt-3 text-primary"><a href="<?php echo e(url('organization/'.$data->organization->id.'/'.$data->organization->first_name.'-'.$data->organization->last_name)); ?>"> <?php echo e(__('Profile')); ?></a></button>
                              </div>
                            </div>
                          </div>

                        </div>
                      </div>
                </div>

            </div>
        </div>
        <div class="col-md-12 ticket-section">
            <div class="title-box-d">
                <h3 class="title-d"><?php echo e(__('Tickets on sale')); ?></h3>
            </div>
            <ul class="nav nav-pills-a nav-pills mb-4 section-t1" id="pills-tab" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" id="pills-video-tab" data-toggle="pill" href="#pills-video" role="tab" aria-controls="pills-video" aria-selected="true"><?php echo e(__('Paid')); ?></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" id="pills-plans-tab" data-toggle="pill" href="#pills-plans" role="tab" aria-controls="pills-plans" aria-selected="false"><?php echo e(__('Free')); ?></a>
                </li>
            </ul>

            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="pills-video" role="tabpanel" aria-labelledby="pills-video-tab">
                  <div class="row">
                    <?php if(count($data->paid_ticket)==0): ?>
                      <div class="col-lg-12 text-center">
                        <div class="empty-state">
                          <img src="<?php echo e(url('frontend/images/empty.png')); ?>">
                          <h6 class="mt-4"> <?php echo e(__('No Paid Tickets found')); ?>!</h6>
                        </div>
                      </div>
                    <?php else: ?>
                      <?php $__currentLoopData = $data->paid_ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                          <article class="ticket">
                            <header class="ticket__wrapper">
                              <div class="ticket__header">
                                <span><?php echo e($item->ticket_number); ?></span>
                                <?php if($item->type=="free"): ?>
                                <span><?php echo e(__('FREE')); ?></span>
                                <?php else: ?>
                                  <span><?php echo e($currency.$item->price); ?></span>
                                <?php endif; ?>
                              </div>
                            </header>
                            <div class="ticket__divider">
                              <div class="ticket__notch"></div>
                              <div class="ticket__notch ticket__notch--right"></div>
                            </div>
                            <div class="ticket__body">
                              <section class="ticket__section">
                                <h3><?php echo e($item->name); ?></h3>
                                <p><?php echo e($item->description); ?></p>
                              </section>
                              <section class="ticket__section">
                                <h3><?php echo e(__('Sales')); ?></h3>
                                <p class="mb-0"><span><?php echo e(__('Start')); ?> : </span><?php echo e($item->start_time->format('Y-m-d h:i a')); ?></p>
                                <p class="mb-0"><span><?php echo e(__('end')); ?> : </span><?php echo e($item->end_time->format('Y-m-d h:i a')); ?></p>
                                <?php if($item->available_qty <= 0): ?>
                                <?php else: ?>
                                  <p><span><?php echo e(__('Quantity')); ?> : </span><?php echo e($item->available_qty.' pcs left'); ?></p>
                                <?php endif; ?>
                              </section>
                            </div>
                            <footer class="ticket__footer text-right">
                              <?php if($item->available_qty <= 0): ?>
                              <p class="mt-1 mb-1 text-center coupon-data"><?php echo e(__('Sold Out')); ?></p>
                              <?php else: ?>
                                <?php if(Auth::guard('appuser')->check()): ?>
                                  <a href="<?php echo e(url('checkout/'.$item->id)); ?>"><button class="btn btn-a" ><?php echo e(__('Book Now')); ?></button></a>
                                <?php else: ?>
                                  <a href="<?php echo e(url('user/login')); ?>"><button class="btn btn-a" ><?php echo e(__('Book Now')); ?></button></a>
                                <?php endif; ?>
                              <?php endif; ?>
                            </footer>
                          </article>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="tab-pane fade" id="pills-plans" role="tabpanel" aria-labelledby="pills-plans-tab">
                  <div class="row">
                    <?php if(count($data->free_ticket)==0): ?>
                      <div class="col-lg-12 text-center">
                        <div class="empty-state">
                          <img src="<?php echo e(url('frontend/images/empty.png')); ?>">
                          <h6 class="mt-4"> <?php echo e(__('No Free Tickets found')); ?>!</h6>
                        </div>
                      </div>
                    <?php else: ?>
                      <?php $__currentLoopData = $data->free_ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                          <article class="ticket">
                            <header class="ticket__wrapper">
                              <div class="ticket__header">
                                <span><?php echo e($item->ticket_number); ?></span>
                                <?php if($item->type=="free"): ?>
                                <span>FREE</span>
                                <?php else: ?>
                                  <span><?php echo e($currency.$item->price); ?></span>
                                <?php endif; ?>
                              </div>
                            </header>
                            <div class="ticket__divider">
                              <div class="ticket__notch"></div>
                              <div class="ticket__notch ticket__notch--right"></div>
                            </div>
                            <div class="ticket__body">
                              <section class="ticket__section">
                                <h3><?php echo e($item->name); ?></h3>
                                <p><?php echo e($item->description); ?></p>
                              </section>
                              <section class="ticket__section">
                                <h3><?php echo e(__('Sales')); ?></h3>
                                <p class="mb-0"><span><?php echo e(__('Start')); ?> : </span><?php echo e($item->start_time->format('Y-m-d h:i a')); ?></p>
                                <p class="mb-0"><span><?php echo e(__('end')); ?> : </span><?php echo e($item->end_time->format('Y-m-d h:i a')); ?></p>
                                <?php if($item->available_qty <= 0): ?>

                                <?php else: ?>
                                  <p><span><?php echo e(__('Quantity')); ?> : </span><?php echo e($item->available_qty.' pcs left'); ?></p>
                                <?php endif; ?>
                              </section>
                            </div>
                            <footer class="ticket__footer text-right">
                              <?php if($item->available_qty <= 0): ?>
                              <p class="mt-1 mb-1 text-center coupon-data">Sold Out</p>
                              <?php else: ?>
                                <?php if(Auth::guard('appuser')->check()): ?>
                                  <a href="<?php echo e(url('checkout/'.$item->id)); ?>"><button class="btn btn-a"><?php echo e(__('Book Now')); ?></button></a>
                                <?php else: ?>
                                  <a href="<?php echo e(url('user/login')); ?>"><button class="btn btn-a"><?php echo e(__('Book Now')); ?></button></a>
                                <?php endif; ?>
                              <?php endif; ?>
                            </footer>
                          </article>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </div>
                </div>
            </div>

        </div>

        <div class="col-md-12 col-lg-12 mt-8">















































          <div class="title-box-d mt-8">
          <h3 class="title-d"><?php echo e(__('Reviews')); ?> (<?php echo e(count($data->review)); ?>)</h3>
          </div>
          <div class="box-comments">
            <ul class="list-comments">
              <?php if(count($data->review)==0): ?>
                <div class="empty-state text-center">
                  <img src="<?php echo e(url('frontend/images/empty.png')); ?>">
                  <h6 class="mt-4"> <?php echo e(__('No Reviews found')); ?>!</h6>
                </div>
              <?php else: ?>
                <?php $__currentLoopData = $data->review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <div class="comment-avatar">
                      <img src="<?php echo e($item->user->imagePath .'/'.$item->user->image); ?>" alt="">
                    </div>
                    <div class="comment-details">
                      <h4 class="comment-author"> <?php echo e($item->user->name .' '.$item->user->last_name); ?> </h4>
                      <span> <?php echo e(\Carbon\Carbon::parse($item->created_at)->format('Y-m-d H:i a')); ?> </span>
                      <p class="comment-description">
                        <?php echo e($item->message); ?>

                      </p>
                    </div>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </ul>
          </div>

        </div>


      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', ['activePage' => 'event'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/eventDetail.blade.php ENDPATH**/ ?>