

<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php echo $__env->make('admin.layout.breadcrumbs', [
            'title' => __('Event Detail'),  
            'headerData' => __('Event') ,
            'url' => 'events' ,          
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

      <div class="section-body">      
         <div class="row event-single">
             <div class="col-lg-8">                 
                 <div class="card">
                     <div class="card-body">
                        <div class="row">
                            <div class="col-12 mb-3">
                                <div class="event-img w-100" style="background: url(<?php echo e(url('images/upload/'.$event->image)); ?>)">                            
                                </div>
                            </div>
                            <div class="col-12 event-description">
                                <h2 class="mt-3"><?php echo e($event->name); ?> <button type="button" class="btn btn-primary "><a class="text-white" href="<?php echo e(url($event->id.'/'.preg_replace('/\s+/', '-', $event->name).'/tickets')); ?>"><?php echo e(__('Manage Tickets')); ?></a></button></h2>
                                <p> <?php echo $event->description; ?>  </p>                                                               
                            </div>                                                                                    
                        </div> 
                        <div class="row ml-0 mr-0 mt-4">
                            <div class="col-lg-3">
                                <div class="card single-card-light">
                                    <div class="row">
                                        <div class="col-3 text-center">
                                            <i class="fas fa-users"></i>
                                        </div>
                                        <div class="col-9">
                                            <p class="mb-0"><?php echo e(__('People allowed')); ?></p>
                                            <span><?php echo e($event->people); ?></span>
                                        </div>
                                    </div>
                                </div>                               
                            </div>                         
                            <div class="col-lg-4">
                                <div class="card single-card-light">
                                    <div class="row">
                                        <div class="col-3 text-center">
                                            <i class="far fa-calendar-alt"></i>
                                        </div>
                                        <div class="col-9">
                                            <p class="mb-0"><?php echo e(__('Date')); ?></p>
                                            <span><?php echo e(Carbon\Carbon::parse($event->start_time)->format('l').','); ?></span>
                                            <span><?php echo e($event->start_time->format('d F Y')); ?></span>
                                        </div>
                                    </div>
                                </div>                               
                            </div>
                            <div class="col-lg-5">
                                <div class="card single-card-light">
                                    <div class="row">
                                        <div class="col-2 text-center">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                        <div class="col-9">
                                            <p class="mb-0"><?php echo e(__('Location')); ?></p>
                                            <?php if($event->type=="offline"): ?>
                                            <span> <?php echo e($event->address); ?> </span>
                                            <?php else: ?> 
                                            <span> <?php echo e(__('Online Event')); ?> </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>                               
                            </div>
                        </div>                      
                     </div>
                </div>
                <h2 class="section-title"> <?php echo e(__('Recent Sales')); ?></h2>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table" id="">
                                <thead>
                                    <tr>                                                                          
                                        <th><?php echo e(__('Order Id')); ?></th>
                                        <th><?php echo e(__('Customer Name')); ?></th>
                                        <th><?php echo e(__('Ticket Name')); ?></th>
                                        <th><?php echo e(__('Date')); ?></th>                                       
                                        <th><?php echo e(__('Sold Ticket')); ?></th>                                        
                                        <th><?php echo e(__('Payment')); ?></th>                                        
                                        <th><?php echo e(__('Payment Gateway')); ?></th>                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $event->sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->order_id); ?></td>
                                            <td><?php echo e($item->customer->name); ?></td>
                                            <th><?php echo e($item->ticket->name); ?></th>
                                            <th><?php echo e($item->created_at->format('Y-m-d')); ?></th>
                                            <th><?php echo e($item->quantity); ?></th>
                                            <th><?php echo e($currency.$item->payment); ?></th>
                                            <th><?php echo e($item->payment_type); ?></th>                                                                                      
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                                </tbody>
                            </table>
                        </div>
                    </div> 
                </div>
             </div>
             <div class="col-lg-4">
                 <?php if(count($event->ticket)>0): ?>
                    <?php $__currentLoopData = $event->ticket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card card-hero">
                            <div class="card-header">
                                <p class="text-right"><?php echo e(__('Sales end on')); ?></p>
                                <p class="text-right"><?php echo e($item->start_time->format('Y-m-d').','.$item->end_time->format('h:i a')); ?></p>
                                <div class="card-icon">
                                    <i class="fas fa-ticket-alt"></i>
                                </div>
                                <div class="card-description"><?php echo e($item->name); ?> | <span><?php echo e($currency.$item->price); ?></span></div>
                                <h4><?php echo e($item->used_ticket.'/'.$item->quantity); ?> </h4>                                
                            </div>
                        </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?> 
                
                <div class="card card-hero">
                    <div class="card-header">
                       
                    <div class="card-icon">
                        <i class="fas fa-ticket-alt"></i>
                    </div>
                    <div class="card-description"><?php echo e(__('No tickets')); ?></div>
                    <a href="<?php echo e(url($event->id.'/ticket/create')); ?>"><button type="button" class="btn btn-ticket" ><i class="fas fa-plus"></i> </button>  </a>                  
                    </div>
                </div> 
                <?php endif; ?>
                
             </div>
         </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/event/view.blade.php ENDPATH**/ ?>