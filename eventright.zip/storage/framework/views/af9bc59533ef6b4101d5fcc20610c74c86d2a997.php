

<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Reviews'),            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="section-body">
        <h2 class="section-title"><?php echo e(__('Reviews')); ?></h2>
        <p class="section-lead"></p>    
        <div class="row mt-sm-4">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12">
                <div class="card">     
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table" id="report_table">
                            <thead>
                                <tr>
                                    <th></th>                              
                                    <th><?php echo e(__('Customer')); ?></th>
                                    <th><?php echo e(__('Event Name')); ?></th>                           
                                    <th><?php echo e(__('Message')); ?></th>  
                                    <th><?php echo e(__('Rate')); ?></th>  
                                    <?php if(Auth::user()->hasRole('admin')): ?>
                                    <th><?php echo e(__('Action')); ?></th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td></td>                                     
                                        <td>
                                            <div class="media">
                                                <img alt="image" class="mr-3 avatar" src="<?php echo e(url('images/upload/'.$item->user->image)); ?>">
                                                <div class="media-body">
                                                    <div class="media-title mb-0">
                                                        <?php echo e($item->user->name.' '.$item->user->last_name); ?>

                                                    </div>
                                                    <div class="media-description text-muted"> <?php echo e($item->user->email); ?> </div>
                                                </div>
                                            </div>
                                        </td>                                                                                  
                                        <td><?php echo e($item->event->name); ?></td>                                                                                   
                                        <td><?php echo e($item->message); ?></td>
                                        <td>
                                            <div class="rating">
                                                <?php for($i = 1; $i <=5; $i++): ?>
                                                    <i class="fas fa-star <?php echo e($item->rate >= $i ? 'active':''); ?>"></i>
                                                <?php endfor; ?>
                                            </div>  
                                        </td>
                                      <?php if(Auth::user()->hasRole('admin')): ?>
                                        <td>                
                                            <?php if($item->status==0): ?>                          
                                            <a href="<?php echo e(url('change-review-status/'.$item->id)); ?>" class="btn-icon  mr-2"><button class="btn btn-primary"><?php echo e(__('Publish')); ?></button></a>                                         
                                            <?php endif; ?>
                                            <a href="<?php echo e(url('delete-review/'.$item->id)); ?>" class="btn-icon "><button class="btn btn-danger"><?php echo e(__('Delete')); ?></button></a>                                         
                                        </td>
                                      <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                            </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
          </div>

        
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/review.blade.php ENDPATH**/ ?>