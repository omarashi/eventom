<footer class="mt-8">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <nav class="nav-footer text-right mb-2">
                    <ul class="list-inline">
                        <li class="list-inline-item">
                            <a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0)"><?php echo e(__('Organizations')); ?></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0)"><?php echo e(__('Privacy Policy')); ?></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0)"><?php echo e(__('Contact')); ?></a>
                        </li>
                    </ul>
                    <div class="dropdown ml-2 mb-2 langDropdown">
                        <?php $lang = session('locale')==null?"English":session('locale'); ?>
                        <?php
                            $languages = \App\Models\Language::where('status',1)->get();
                        ?>
                        <a class="dropdown-toggle" href="javascript:void(0)" id="langDropdown" role="button" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <img src="<?php echo e(url('images/upload/' . $lang . '.png')); ?>" class="flag-img"><?php echo e(__($lang)); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="langDropdown">
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item" href="<?php echo e(url('change-language/'.$language->name)); ?>"><img src="<?php echo e(url('images/upload/'.$language->image)); ?>" class="flag-img"><?php echo e($language->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\eventright\resources\views/frontend/layout/footer.blade.php ENDPATH**/ ?>