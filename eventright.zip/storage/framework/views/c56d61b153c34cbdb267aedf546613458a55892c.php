

<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('View Orders'),            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="section-body">            
       
        <div class="row">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>  
            </div>
            <div class="col-12">
              <div class="card">     
                <div class="card-body">
                    <div class="row mb-4 mt-2">
                        <div class="col-lg-8"><h2 class="section-title mt-0"> <?php echo e(__('Order List')); ?></h2></div>
                        <div class="col-lg-4 text-right">                            
                        </div>
                    </div> 
                  <div class="table-responsive">
                    
                    <table class="table" id="report_table">
                        <thead>
                            <tr>
                                <th></th>              
                                <th><?php echo e(__('Order Id')); ?></th>                 
                                <th><?php echo e(__('Customer Name')); ?></th>
                                <th><?php echo e(__('Event Name')); ?></th>
                                <th><?php echo e(__('Date')); ?></th>                                
                                <th><?php echo e(__('Sold Ticket')); ?></th>                                
                                <th><?php echo e(__('Payment')); ?></th>  
                                <th><?php echo e(__('Payment Gateway')); ?></th>
                                <th><?php echo e(__('Order Status')); ?></th> 
                                <th><?php echo e(__('Payment Status')); ?></th>                                                                
                                <th><?php echo e(__('Action')); ?></th>                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td><?php echo e($item->order_id); ?> </td>
                                    <td><?php echo e($item->customer->name.' '.$item->customer->last_name); ?></td>                                                                                   
                                    <td>
                                        <h6 class="mb-0"><?php echo e($item->event->name); ?></h6>
                                        <p class="mb-0"><?php echo e($item->event->start_time); ?></p>
                                    </td>
                                    <td>
                                        <p class="mb-0"><?php echo e($item->created_at->format('Y-m-d')); ?></p>
                                        <p class="mb-0"><?php echo e($item->created_at->format('h:i a')); ?></p>
                                    </td>                                    
                                    <td><?php echo e($item->quantity.' ticket'); ?></td>
                                    <td><?php echo e($currency.$item->payment); ?></td>
                                    <td><?php echo e($item->payment_type); ?></td>
                                    <td>
                                        <select name="order_status" id="status-<?php echo e($item->id); ?>" class="form-control p-2" onchange="changeOrderStatus(<?php echo e($item->id); ?>)" <?php echo e($item->order_status == "Complete" || $item->order_status == "Cancel"? 'disabled':''); ?>>
                                            <option value="Pending" <?php echo e($item->order_status == "Pending"? 'selected':''); ?>> <?php echo e(__('Pending')); ?> </option>
                                            <option value="Complete" <?php echo e($item->order_status == "Complete"? 'selected':''); ?>> <?php echo e(__('Complete')); ?> </option>
                                            <option value="Cancel" <?php echo e($item->order_status == "Cancel"? 'selected':''); ?>> <?php echo e(__('Cancel')); ?> </option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="payment_status" id="payment-<?php echo e($item->id); ?>" class="form-control p-2" onchange="changePaymentStatus(<?php echo e($item->id); ?>)" <?php echo e($item->payment_status == 1? 'disabled':''); ?>>
                                            <option value="0" <?php echo e($item->payment_status == 0? 'selected':''); ?>> <?php echo e(__('Pending')); ?> </option>
                                            <option value="1" <?php echo e($item->payment_status == 1? 'selected':''); ?>> <?php echo e(__('Complete')); ?> </option>
                                        </select>
                                    </td> 
                                    <td>
                                        <a href="<?php echo e(url('order-invoice/'.$item->id)); ?>" class="btn-icon text-primary"><i class="far fa-eye"></i></a>                                    
                                    </td>                                 
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                        </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/order/index.blade.php ENDPATH**/ ?>