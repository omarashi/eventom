<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="javascript:void(0)">
                <img src="<?php echo e(url('images/upload/' . \App\Models\Setting::find(1)->logo)); ?>" class="header-logo">
            </a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="javascript:void(0)">
                <img src="<?php echo e(url('images/upload/' . \App\Models\Setting::find(1)->favicon)); ?>" class="header-sm-logo">
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header"><?php echo e(__('Menus')); ?></li>
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin_dashboard')): ?>
                    <li class="<?php echo e(request()->is('admin/home') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('admin/home')); ?>">
                            <i class="fas fa-chart-pie"></i> <span><?php echo e(__('Dashboard')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(auth()->check() && auth()->user()->hasRole('organization')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('organization_dashboard')): ?>
                    <li class="<?php echo e(request()->is('organization/home') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('organization/home')); ?>">
                            <i class="fas fa-chart-pie"></i> <span><?php echo e(__('Dashboard')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                <li class="<?php echo e(request()->is('roles*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('roles')); ?>">
                        <i class="fas fa-user-secret"></i> <span><?php echo e(__('Role')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                <li class="<?php echo e(request()->is('users*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('users')); ?>">
                        <i class="fas fa-user-friends"></i> <span><?php echo e(__('Users')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <li class="<?php echo e(request()->is('orders*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('orders')); ?>">
                    <i class="fas fa-columns"></i><span><?php echo e(__('Orders')); ?></span>
                </a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category_access')): ?>
                <li class="<?php echo e(request()->is('category*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('category')); ?>">
                        <i class="fas fa-glass-cheers"></i> <span><?php echo e(__('Category')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_access')): ?>
                <li class="<?php echo e(request()->is('events*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('events')); ?>">
                        <i class="fas fa-calendar-alt"></i> <span><?php echo e(__('Events')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <li class="<?php echo e(request()->is('app-user*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('app-user')); ?>">
                    <i class="fas fa-users"></i> <span><?php echo e(__('App Users')); ?></span>
                </a>
            </li>





















            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('banner_access')): ?>
                <li class="<?php echo e(request()->is('banner*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(url('banner')); ?>">
                        <i class="fas fa-images"></i><span><?php echo e(__('Banner')); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <li class="<?php echo e(request()->is('user-review') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('user-review')); ?>">
                    <i class="fas fa-star"></i> <span><?php echo e(__('Review')); ?></span>
                </a>
            </li>





















            <?php if(auth()->check() && auth()->user()->hasRole('organization')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('organization_report')): ?>
                    <li class="nav-item dropdown <?php echo e(request()->is('organization-report*') ? 'active' : ''); ?>">
                        <a href="javascript:void(0)" class="nav-link has-dropdown" data-toggle="dropdown"><i class="fas fa-chart-bar"></i>
                            <span><?php echo e(__('Reports')); ?></span></a>
                        <ul class="dropdown-menu">
                            <li><a class="nav-link"
                                    href="<?php echo e(url('organization-report/customer')); ?>"><?php echo e(__('Customer Report')); ?></a></li>
                            <li><a class="nav-link"
                                    href="<?php echo e(url('organization-report/orders')); ?>"><?php echo e(__('Orders Report')); ?></a></li>
                            <li><a class="nav-link"
                                    href="<?php echo e(url('organization-report/revenue')); ?>"><?php echo e(__('Revenue Report')); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            <?php endif; ?>








            <?php if(auth()->check() && auth()->user()->hasRole('organization')): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tax_access')): ?>
                    <li class="<?php echo e(request()->is('tax*') ? 'active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e(url('tax')); ?>">
                            <i class="fas fa-hand-holding-usd"></i><span><?php echo e(__('Tax')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>





























        </ul>
    </aside>
</div>
<?php /**PATH C:\laragon\www\eventright\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>