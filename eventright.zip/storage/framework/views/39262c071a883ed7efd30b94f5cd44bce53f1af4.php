<div class="click-closed"></div>
  <div class="box-collapse">
    <div class="title-box-d">
      <h3 class="title-d"><?php echo e(__('Search Events')); ?></h3>
    </div>
    <span class="close-box-collapse right-boxed ion-ios-close"></span>
    <div class="box-collapse-wrap form">
      <form class="form-a" method="post" action="<?php echo e(url('all-events')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
          <div class="col-md-12 mb-2">
            <?php $cat = App\Models\Category::where('status',1)->orderBy('id','DESC')->get(); ?>
            <div class="form-group">
              <label class="pb-2"><?php echo e(__('Category')); ?></label>
              <select class="form-control select2" name="category">
                <option value=""><?php echo e(__('All')); ?></option>
                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="col-md-12 mb-2">
            <div class="form-group mt-3">
              <label class="pb-2" for="type"><?php echo e(__('Event Type')); ?></label>
              <select class="form-control select2" name="type" id="type">
                <option value=""><?php echo e(__('All')); ?></option>
                <option value="online"><?php echo e(__('Online Event')); ?></option>
                <option value="offline"><?php echo e(__('Venues')); ?></option>            
              </select>
            </div>
          </div>
          <div class="col-md-12 mb-2">
            <div class="form-group mt-3">
              <label class="pb-2" for="duration"><?php echo e(__('Duration')); ?></label>
              <select class="form-control select2" id="duration" name="duration">
                <option value=""><?php echo e(__('All')); ?></option>
                <option value="Today"><?php echo e(__('Today')); ?></option>
                <option value="Tomorrow"><?php echo e(__('Tomorrow')); ?></option>
                <option value="ThisWeek"><?php echo e(__('This Week')); ?></option>
                <option value="date"><?php echo e(__('Choose a date')); ?></option>
              </select>
            </div>
          </div>
          <div class="col-md-12 mb-2 date-section hide">
            <div class="form-group mt-3">
              <label class="pb-2" for="date"><?php echo e(__('Date')); ?></label> 
              <input class="form-control form-control-a date" placeholder="<?php echo e(__('Choose date')); ?>" name="date" id="date">
               
            </div>
          </div>        
          <div class="col-md-12">
            <button type="submit" class="btn btn-b"><?php echo e(__('Search')); ?></button>
          </div>
        </div>
      </form>
    </div>
  </div><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/layout/search.blade.php ENDPATH**/ ?>