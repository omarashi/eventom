

<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Notification'),            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="section-body">
        <h2 class="section-title"><?php echo e(__('Notification')); ?></h2>
        <p class="section-lead">            
        </p>    
        <div class="row mt-sm-4">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div> 
            <div class="col-12">
                <div class="activities">
                    <?php if(count($notification)==0): ?>
                      <div class="empty-data text-center">
                        <div class="card-icon shadow-primary">
                          <i class="fas fa-bell"></i>
                        </div>
                        <h6 class="mt-3"><?php echo e(__('No Notification found')); ?> </h6>
                      </div>
                    <?php else: ?> 
                      <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <?php if($item->user!=null): ?>                                                
                            <div class="activity">
                                <div class="activity-icon bg-primary text-white shadow-primary">                               
                                <img src="<?php echo e(url('images/upload/'.$item->user->image)); ?>" class="avatar">
                                </div>
                                <div class="activity-detail">
                                <div class="mb-2">
                                    <span class="text-job text-primary"><?php echo e($item->created_at->diffForHumans()); ?></span>
                                    <span class="bullet"></span>
                                    <a class="text-job" href="javascript:void(0)"><?php echo e($item->user->name.' '.$item->user->last_name); ?></a>
                                    <div class="float-right dropdown">
                                    <a href="javascript:void(0)" data-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></a>
                                    <div class="dropdown-menu">
                                        <div class="dropdown-title"><?php echo e(__('Options')); ?></div>
                                        <a href="<?php echo e(url('orders/'.$item->order_id)); ?>" class="dropdown-item has-icon"><i class="fas fa-eye"></i> <?php echo e(__('View')); ?></a>                                        
                                        <div class="dropdown-divider"></div>
                                        <a href="<?php echo e(url('delete-notification/'.$item->id)); ?>" class="dropdown-item has-icon text-danger" ><i class="fas fa-trash-alt"></i> <?php echo e(__('Archive')); ?></a>
                                    </div>
                                    </div>
                                </div>
                                <p><?php echo e($item->message); ?></p>
                                </div>
                            </div>   
                        <?php endif; ?>                   
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  
                
                </div>
              </div>                   
          </div>

        
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/notification.blade.php ENDPATH**/ ?>