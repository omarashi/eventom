<section class="intro-single">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-lg-8">
                <div class="title-single-box"><h1 class="title-single"><?php echo e($title); ?></h1></div>
            </div>
            <div class="col-md-3 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page"> <?php echo e($page); ?> </li>
                </ol>
            </nav>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/layout/breadcrumbs.blade.php ENDPATH**/ ?>