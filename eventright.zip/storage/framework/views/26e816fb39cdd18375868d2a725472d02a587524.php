<?php $__env->startSection('content'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('Customer Detail'),            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="section-body">
        <h2 class="section-title"><?php echo e($user->name.' '.$user->last_name); ?></h2>
       
        <div class="row mt-sm-4">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12 col-md-12 col-lg-5">
              <div class="card profile-widget">
                <div class="profile-widget-header">
                  <img alt="image" src="<?php echo e(url('images/upload/'.$user->image)); ?>" class="rounded-circle profile-widget-picture">
                  <div class="profile-widget-items">                                        
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label"><?php echo e(__('Pending Order')); ?></div>
                            <div class="profile-widget-item-value"><?php echo e($user->pending); ?></div>
                        </div>
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label"><?php echo e(__('Complete Order')); ?></div>
                            <div class="profile-widget-item-value"><?php echo e($user->complete); ?></div>
                        </div>    
                        <div class="profile-widget-item">
                            <div class="profile-widget-item-label"><?php echo e(__('Cancel Order')); ?></div>
                            <div class="profile-widget-item-value"><?php echo e($user->cancel); ?></div>
                        </div>                                                    
                  </div>
                </div>
                <div class="profile-widget-description">
                  <div class="profile-widget-name"><?php echo e($user->name.' '.$user->last_name); ?></div>
                   <b><?php echo e($user->email); ?></b>
                   <p><?php echo e($user->address); ?></p>
                </div>              
              </div>

                
                <div class="card mt-4">
                    <div class="card-header">
                        <h4><?php echo e(__('Following ('.count($user->following).')')); ?></h4>
                    </div>
                    <div class="card-body scroll-type">
                        <?php if(count($user->following)==0): ?>
                            <div class="row">
                                <div class="col-12 text-center">
                                    <div class="empty-data">
                                        <div class="card-icon shadow-primary">
                                        <i class="fas fa-search"></i>
                                        </div>
                                        <h6 class="mt-3"><?php echo e(__('No Data found')); ?> </h6>
                                    </div>                                    
                                </div>
                            </div>
                        <?php else: ?> 
                            <ul class="list-unstyled list-unstyled-border">                              
                                <?php $__currentLoopData = $user->following; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="media">
                                        <img class="mr-3 avatar" width="50" src="<?php echo e(url('images/upload/'.$item->image)); ?>" alt="avatar">
                                        <div class="media-body">                                      
                                            <div class="media-title"><?php echo e($item->first_name.' '.$item->last_name); ?></div>
                                            <span class="text-small text-muted"><?php echo e($item->email); ?></span>
                                        </div>
                                     </li>                                                                  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                               
                            </ul>
                        <?php endif; ?>                                                                              
                    </div>
                </div>
             
            </div>
            <div class="col-12 col-md-12 col-lg-7">
              <div class="card mt-4">
                  <div class="card-header">
                    <h4><?php echo e(__('All Orders')); ?>(<?php echo e(($user->pending+ $user->cancel + $user->complete)); ?>)</h4>
                  </div>
                                   
                  <div class="card-body">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link active" id="upcoming-tab" data-toggle="tab" href="#upcoming" role="tab" aria-controls="upcoming" aria-selected="true"><?php echo e(__('Upcoming')); ?></a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="past-tab" data-toggle="tab" href="#past" role="tab" aria-controls="past" aria-selected="false"><?php echo e(__('Past')); ?></a>
                        </li>                      
                      </ul>
                      <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="upcoming" role="tabpanel" aria-labelledby="upcoming-tab">
                            <?php if(count($user->upcoming)==0): ?>
                                <div class="row">
                                    <div class="col-12 text-center">
                                        <div class="empty-data">
                                            <div class="card-icon shadow-primary">
                                            <i class="fas fa-search"></i>
                                            </div>
                                            <h6 class="mt-3"><?php echo e(__('No Orders found')); ?> </h6>
                                        </div>                                  
                                    </div>
                                </div>
                            <?php else: ?>                            
                                <?php $__currentLoopData = $user->upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        if($item->order_status=="Pending"){ $status= "badge-warning"; }
                                        else if($item->order_status=="Complete"){ $status= "badge-success"; }
                                        else if($item->order_status=="Cancel"){ $status= "badge-danger"; }
                                    ?>
                                    <div class="row all-orders mb-4">
                                        <div class="col-lg-6">
                                            <a href="<?php echo e(url('order-invoice/'.$item->id)); ?>"><span><?php echo e($item->order_id); ?></span></a>
                                            <h6 class="mb-0"><?php echo e($item->event->name .' ('. $item->quantity.' Tickets)'); ?></h6>                                       
                                            <p><?php echo e($item->event->start_time->format('Y-m-d H:i a')); ?></p>
                                        </div>    
                                        <div class="col-lg-6 text-right">
                                            <button class="btn pr-0"><strong><?php echo e($currency.$item->payment.'.00'); ?></strong></button>                                            
                                            <h6><span class="badge <?php echo e($status); ?>"><?php echo e($item->order_status); ?></span></h6>
                                        </div>                                       
                                    </div>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <div class="tab-pane fade" id="past" role="tabpanel" aria-labelledby="past-tab">
                            <?php if(count($user->past)==0): ?>
                                <div class="row">
                                    <div class="col-12 text-center">
                                        <div class="empty-data">
                                            <div class="card-icon shadow-primary">
                                            <i class="fas fa-search"></i>
                                            </div>
                                            <h6 class="mt-3"><?php echo e(__('No Orders found')); ?> </h6>
                                        </div>                                    
                                    </div>
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $user->past; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        if($item->order_status=="Pending"){ $status= "badge-warning"; }
                                        else if($item->order_status=="Complete"){ $status= "badge-success"; }
                                        else if($item->order_status=="Cancel"){ $status= "badge-danger"; }
                                    ?>
                                    <div class="row all-orders mb-4">
                                        <div class="col-lg-6">
                                            <a href="<?php echo e(url('order-invoice/'.$item->id)); ?>"><span><?php echo e($item->order_id); ?></span></a>
                                            <h6 class="mb-0"><?php echo e($item->event->name .' ('. $item->quantity.' Tickets)'); ?></h6>                                       
                                            <p><?php echo e($item->event->start_time->format('Y-m-d H:i a')); ?></p>
                                        </div>    
                                        <div class="col-lg-6 text-right">
                                            <button class="btn pr-0"><strong><?php echo e($currency.$item->payment.'.00'); ?></strong></button>                                            
                                            <h6><span class="badge <?php echo e($status); ?>"><?php echo e($item->order_status); ?></span></h6>
                                        </div>                                       
                                    </div>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                      
                      </div>
                                                
                  </div>
                 
               
              </div>
            </div>
          </div>

        
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/appUser/view.blade.php ENDPATH**/ ?>