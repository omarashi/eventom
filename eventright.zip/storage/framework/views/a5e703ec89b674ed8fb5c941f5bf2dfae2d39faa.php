<nav class="navbar navbar-default navbar-trans navbar-expand-lg top-header fixed-top <?php echo e(url()->current() == url('/')?'':'navbar-another'); ?>">
    <div class="container">
      <a class="navbar-brand text-brand" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(url('frontend/images/logo.png')); ?>">
      </a>






      <button type="button" class="btn btn-b-n navbar-toggle-box-collapse d-none d-md-block search-btn" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-expanded="false">
        <span class="fa fa-search" aria-hidden="true"></span>
      </button>
      <?php if(Auth::guard('appuser')->check()): ?>
        <div class="dropdown ml-2 profileDropdown">
            <a class="dropdown-toggle" href="javascript:void(0)" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <img class="header-profile-img" src="<?php echo e(url('images/upload/'.Auth::guard('appuser')->user()->image)); ?>">
            </a>
            <div class="dropdown-menu" aria-labelledby="profileDropdown">
              <a class="dropdown-item" href="<?php echo e(url('user/profile')); ?>"><?php echo e(__('Profile')); ?></a>
              <a class="dropdown-item" href="<?php echo e(url('my-tickets')); ?>"><?php echo e(__('My Tickets')); ?></a>
              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
              document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>
            </div>
        </div>

      <?php endif; ?>

    </div>
</nav>

<nav class="navbar navbar-default navbar-trans navbar-expand-lg menu-header second-menu">
  <div class="container">
    <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarDefault" aria-controls="navbarDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span></span>
      <span></span>
      <span></span>
    </button>
    <button type="button" class="btn btn-link nav-search navbar-toggle-box-collapse d-md-none" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-expanded="false">
      <span class="fa fa-search" aria-hidden="true"></span>
    </button>
    <div class="navbar-collapse collapse" id="navbarDefault">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link <?php echo e($activePage == 'home'  ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i><?php echo e(__('Home')); ?></a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e($activePage == 'event'  ? 'active' : ''); ?>" href="<?php echo e(url('all-events')); ?>"><i class="fa fa-calendar"></i><?php echo e(__('Events')); ?></a>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?php echo e($activePage == 'category'  ? 'active' : ''); ?>" href="javascript:void(0)" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-bars"></i><?php echo e(__('Explore Category')); ?>

          </a>
          <?php $category = App\Models\Category::where('status',1)->orderBy('id','DESC')->get(); ?>
          <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a class="dropdown-item <?php echo e(request()->is('events-category/'.$item->id.'/'. preg_replace('/\s+/', '-', $item->name))  ? 'active' : ''); ?>" href="<?php echo e(url('events-category/'.$item->id.'/'. preg_replace('/\s+/', '-', $item->name))); ?>"><?php echo e($item->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a class="dropdown-item <?php echo e(request()->is('all-category')  ? 'active' : ''); ?>" href="<?php echo e(url('all-category')); ?>"><?php echo e(__('All Category')); ?></a>
          </div>
        </li>




        <li class="nav-item">
          <a class="nav-link <?php echo e($activePage == 'contact'  ? 'active' : ''); ?>" href="<?php echo e(url('contact')); ?>"><i class="fa fa-id-badge"></i><?php echo e(__('Contact')); ?></a>
        </li>
        <?php if(!Auth::guard('appuser')->check()): ?>
          <?php
              Auth::logout();
          ?>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(url('user/login')); ?>"><i class="fa fa-lock"></i><?php echo e(__('Sign in')); ?></a>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <a class="nav-link <?php echo e($activePage == 'ticket'  ? 'active' : ''); ?>" href="<?php echo e(url('my-tickets')); ?>"><i class="fa fa-ticket"></i><?php echo e(__('My Tickets')); ?></a>
        </li>
        <?php endif; ?>
      </ul>
    </div>

  </div>
</nav>

  <?php if(url()->current() == url('/')): ?>

  <?php $banner = App\Models\Banner::where('status',1)->orderBy('id','DESC')->get(); ?>
    <div class="intro intro-carousel">
      <div id="carousel" class="owl-carousel owl-theme">
        <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="carousel-item-a intro-item bg-image" style="background-image: url(<?php echo e(url('images/upload/'.$item->image)); ?>)">
            <div class="overlay overlay-a"></div>
            <div class="intro-content display-table">
              <div class="table-cell">
                <div class="container">
                  <div class="row">
                    <div class="col-lg-8">
                      <div class="intro-body">
                        <h1 class="intro-title mb-4">
                          <span class="color-b"><?php echo e(explode(' ',$item->title)[0]); ?> </span>
                          <?php $__currentLoopData = explode(' ',$item->title); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($loop->iteration>1?$item:''); ?>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h1>
                        <p class="intro-subtitle intro-price">
                          <a href="<?php echo e(url('all-events')); ?>"><span class="price-a"><?php echo e(__('Book Now')); ?></span></a>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

  <?php endif; ?>
<?php /**PATH C:\laragon\www\eventright\resources\views/frontend/layout/header.blade.php ENDPATH**/ ?>