

<?php $__env->startSection('content-license'); ?>
<section class="section">
    <?php echo $__env->make('admin.layout.breadcrumbs', [
        'title' => __('License Setting'),                  
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <div class="section-body">
        <div class="row">
            <div class="col-lg-8"><h2 class="section-title"> <?php echo e(__('License Setting')); ?></h2></div>           
        </div>       
       
        <div class="row">
            <div class="col-12">
                <?php if(session('status')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('status')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-12">
              <div class="card">     
                <div class="card-body">
                    <form method="post" action="<?php echo e(url('save-license-setting')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label><?php echo e(__('License Key')); ?></label>
                        <input type="text" name="license_key" placeholder="<?php echo e(__('License Key')); ?>" <?php echo e($setting->license_status==1?'disabled':''); ?> value="<?php echo e($setting->license_key); ?>" class="form-control <?php $__errorArgs = ['license_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['license_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Client Name')); ?></label>
                            <input type="text" name="license_name" placeholder="<?php echo e(__('Client Name')); ?>" <?php echo e($setting->license_status==1?'disabled':''); ?> value="<?php echo e($setting->license_name); ?>" class="form-control <?php $__errorArgs = ['license_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>? is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__errorArgs = ['license_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">                            
                            <button type="submit" <?php echo e($setting->license_status==1?'disabled':''); ?> class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                            
                        </div>
                    </form>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/license.blade.php ENDPATH**/ ?>