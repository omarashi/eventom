

<?php $__env->startSection('content'); ?>
 
    <?php echo $__env->make('frontend.layout.breadcrumbs', [
        'title' => __('Our Latest Blog'),            
        'page' => __('Blogs'),            
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

  
<section class="property-grid grid">
    <div class="container">
      <div class="row">
     
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
              <div class="owl-theme blog-section mb-5">                
                  <div class="carousel-item-c">
                    
                    <div class="card-box-b card-shadow news-box radius-10">
                      <div class="fav-section">                     
                        <?php if(Auth::guard('appuser')->check()): ?>                                     
                          <button type="button" onclick="addFavorite(<?php echo e($item->id); ?>,'blog')" class="btn p-0">
                            <i class="fa fa-heart <?php echo e(in_array($item->id,array_filter(explode(',',Auth::guard('appuser')->user()->favorite_blog)))==true?'active':''); ?>"></i>
                          </button>
                        <?php else: ?> 
                          <button type="button" class="btn p-0">
                            <a href="<?php echo e(url('user/login')); ?>"><i class="fa fa-heart"></i></a>
                          </button>
                        <?php endif; ?>
                      </div>
                      <div class="img-box-b">
                        <img src="<?php echo e(url('images/upload/'.$item->image)); ?>" alt="" class="img-b img-fluid">
                      </div>
                      <div class="card-overlay"></div>               
                    </div>
                    <div class="card-header-b">
                      <div class="card-title-b">
                        <h2 class="title-2">
                          <a href="<?php echo e(url('blog-detail/'.$item->id.'/'.preg_replace('/\s+/', '-', $item->title))); ?>" title="<?php echo e($item->title); ?>"><?php echo e(strlen($item->title)>=50? substr($item->title,0,50).'...':$item->title); ?> </a>
                        </h2>
                      </div>
                      <div class="card-category-b">
                        <span><i class="fa fa-sitemap"></i><?php echo e($item->category->name); ?></span>
                        <span class="date-b"><i class="fa fa-calendar"></i><?php echo e($item->created_at->format('d M.Y')); ?></span>
                      </div>                     
                    </div>
                  </div> 
              </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
      </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', ['activePage' => 'blog'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/blog.blade.php ENDPATH**/ ?>