<?php $__env->startSection('content'); ?>

    <section class="agent-single">
        <div class="profile-top-section" style="background-image: url('https://wallpapercave.com/wp/q1QDvC6.jpg')">
            <div class="profile-overly"></div>
        </div>
        <div class="container">
            <div class="row">


                <div class="col-lg-4 profile-left">
                    <div class="profile-image text-center">
                        <img src="<?php echo e(url('images/upload/'.$user->image)); ?>" id="imagePreview" class="avatar">
                        <div class="edit-profile-img">
                          <form method="post" action="#" id="imageUploadForm" enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>
                            <input type="file" name="image" id="imgUpload" class="hide">
                          </form>
                            <span id="OpenImgUpload"><i class="fa fa-camera"></i></span>
                        </div>
                    </div>
                    <div class="user-description">
                        <h4 class="text-center mb-1"><?php echo e($user->name.' '.$user->last_name); ?></h4>
                        <p class="text-center mb-1"><i class="fa fa-map-marker pr-2"></i><?php echo e($user->address); ?></p>
                        <p class="text-center"><i class="fa fa-envelope pr-2"></i><?php echo e($user->email); ?></p>

                    </div>
                    <div class="user-description bio-section px-5 mt-4">
                        <?php if($user->bio==null): ?>
                        <p class="text-center">
                            <input type="text" name="bio" placeholder="<?php echo e(__('Your Bio')); ?>" class="bio-control hide">
                            <button class="btn btn-bio"><?php echo e(__('Add Bio')); ?> <i class="fa fa-pencil pl-1"></i></button>
                        </p>
                        <?php else: ?>
                            <p class="detail-bio"><?php echo e($user->bio); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="profile-left-link px-5 mt-4">
                      <p><a href="<?php echo e(url('change-password')); ?>"> <?php echo e(__('Change Password')); ?></a></p>
                      <p><a href="<?php echo e(url('my-tickets')); ?>"> <?php echo e(__('My Tickets')); ?></a></p>
                      <p><a href="<?php echo e(url('update_profile')); ?>"> <?php echo e(__('Update Profile')); ?></a></p>
                    </div>
                </div>
                <div class="col-lg-8 profile-right">
                    <div class="row">
                      <div class="col-12">
                        <?php if(session('status')): ?>
                          <div class="alert alert-success alert-dismissible fade show" role="alert">
                              <?php echo e(session('status')); ?>

                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                              </button>
                          </div>
                        <?php endif; ?>
                      </div>
                    </div>
                    <ul class="nav nav-pills-a nav-pills mb-4 section-t1" id="pills-tab" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link active" id="saved-event-tab" data-toggle="pill" href="#saved-event" role="tab" aria-controls="saved-event" aria-selected="true"><?php echo e(__('saved Events')); ?></a>
                        </li>
                    </ul>

                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="saved-event" role="tabpanel" aria-labelledby="saved-event-tab">
                            <div class="row">
                                <?php if(count($user->saved_event) == 0): ?>
                                  <div class="col-lg-12 text-center">
                                    <div class="empty-state">
                                      <img src="<?php echo e(url('frontend/images/empty.png')); ?>">
                                      <h6 class="mt-4"> <?php echo e(__('No Saved Events found')); ?>!</h6>
                                    </div>
                                  </div>
                                <?php else: ?>
                                  <?php $__currentLoopData = $user->saved_event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 events mb-4">
                                        <div class="fav-section">
                                          <?php if(Auth::guard('appuser')->check()): ?>
                                            <button type="button" onclick="addFavorite(<?php echo e($item->id); ?>,'event')" class="btn p-0"> <i class="fa fa-heart <?php echo e(in_array($item->id,array_filter(explode(',',Auth::guard('appuser')->user()->favorite)))==true?'active':''); ?>"></i></button>
                                          <?php else: ?>
                                            <button type="button" class="btn p-0"> <a href="<?php echo e(url('user/login')); ?>"><i class="fa fa-heart"></i></a></button>
                                          <?php endif; ?>
                                        </div>
                                        <div class="card-box-a card-shadow">
                                        <div class="img-box-a">
                                            <img src="<?php echo e(url('images/upload/'.$item->image)); ?>" alt="" class="img-a img-fluid">
                                        </div>
                                        <div class="card-overlay">
                                            <div class="card-overlay-a-content">
                                            <div class="card-header-a">
                                                <h2 class="card-title-a"><a href="<?php echo e(url('event/'.$item->id.'/'.preg_replace('/\s+/', '-', $item->name))); ?>"><?php echo e($item->name); ?></a></h2>
                                            </div>
                                            <div class="card-body-a">
                                                <div class="price-box d-flex">
                                                <span class="price-a"><?php echo e($item->start_time->format('l').', '.$item->start_time->format('d F Y')); ?></span>
                                                </div>
                                                <a href="<?php echo e(url('event/'.$item->id.'/'.preg_replace('/\s+/', '-', $item->name))); ?>" class="link-a"><?php echo e(__('More Detail')); ?>

                                                <span class="ion-ios-arrow-forward"></span>
                                                </a>
                                            </div>
                                            <div class="card-footer-a">
                                                <ul class="card-info d-flex justify-content-around">
                                                    <li>
                                                        <h4 class="card-info-title"><?php echo e(__('Type')); ?></h4>
                                                        <span><?php echo e($item->category->name); ?></span>
                                                    </li>
                                                    <li>
                                                        <h4 class="card-info-title"><?php echo e(__('Available')); ?></h4>
                                                        <span><?php echo e($item->available_ticket.' ticket'); ?></span>
                                                    </li>
                                                </ul>
                                            </div>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', ['activePage' => 'profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/frontend/profile.blade.php ENDPATH**/ ?>