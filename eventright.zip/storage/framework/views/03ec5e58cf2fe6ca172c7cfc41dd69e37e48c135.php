

<?php $__env->startSection('content'); ?>
    <section class="section">
      <div class="section-header">
        <h1><?php echo e(__('Dashboard')); ?> </h1>
      </div>

      <div class="section-body">
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card card-statistic-2">
              <div class="card-stats">
                <div class="card-stats-title"><?php echo e(__('Order Statistics')); ?> -
                  <div class="dropdown d-inline">
                    <a class="font-weight-600 dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" id="orders-month"><?php echo e(__('All')); ?></a>
                      <ul class="dropdown-menu dropdown-menu-sm">
                        <li class="dropdown-title"><?php echo e(__('Select Month')); ?></li>
                        <?php for($i = 1; $i <= 12; $i++): ?>
                          <li><a href="javascript:void(0)" class="dropdown-item" onclick="getStatistics(<?php echo e($i); ?> )"><?php echo e(date("F", mktime(0, 0, 0, $i, 10))); ?></a></li>    
                        <?php endfor; ?>                     
                      </ul>
                  </div>
                </div>
                <div class="card-stats-items">
                  <div class="card-stats-item">
                    <div class="card-stats-item-count order-pending"><?php echo e($master['pending_order']); ?></div>
                    <div class="card-stats-item-label"><?php echo e(__('Pending')); ?></div>
                  </div>
                  <div class="card-stats-item">
                    <div class="card-stats-item-count order-complete"><?php echo e($master['complete_order']); ?></div>
                    <div class="card-stats-item-label"><?php echo e(__('Completed')); ?></div>
                  </div>
                  <div class="card-stats-item">
                    <div class="card-stats-item-count order-cancel"><?php echo e($master['cancel_order']); ?></div>
                    <div class="card-stats-item-label"><?php echo e(__('Cancel')); ?></div>
                  </div>
                </div>
              </div>
              <div class="card-icon shadow-primary bg-primary">
                <i class="fas fa-shopping-bag"></i>
              </div>
              <div class="card-wrap">
                <div class="card-header">
                  <h4><?php echo e(__('Total Orders')); ?></h4>
                </div>
                <div class="card-body order-total">
                  <?php echo e($master['total_order']); ?>

                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card card-hero">
              <div class="card-header">
                <div class="card-icon">
                  <i class="fas fa-ticket-alt"></i>
                </div>
                <h4><?php echo e($master['used_tickets'].'/'.$master['total_tickets']); ?></h4>
                <div class="card-description"><?php echo e(__('Remaining Tickets')); ?></div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="card card-hero">
              <div class="card-header">
                <div class="card-icon">
                  <i class="fas fa-glass-cheers"></i>
                </div>
                <h4><?php echo e($master['events']); ?></h4>
                <div class="card-description"><?php echo e(__('Events')); ?></div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
            <div class="col-lg-9">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card mb-4">
                            <div class="card-header pt-0 pb-0">
                                <div class="row w-100">
                                <div class="col-lg-8">
                                    <h2 class="section-title"> <?php echo e(__('Upcoming Event')); ?></h2>                        
                                </div>
                                <div class="col-lg-4 text-right mt-2">
                                    <a href="<?php echo e(url('events')); ?>"><button class="btn btn-sm btn-primary "><?php echo e(__('See all')); ?></button>   </a>             
                                </div>
                                </div>                                 
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                <table class="table home-tbl" id="">                                    
                                    <tbody>
                                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>                                   
                                                <td> <img class="table-img" src="<?php echo e(url('images/upload/'.$item->image)); ?>"> </td>
                                                <td style="width:360px">
                                                    <h6><?php echo e($item->name); ?></h6>
                                                    <?php if($item->type=="online"): ?>
                                                        <p><?php echo e(__('Online Event')); ?></p>
                                                    <?php else: ?> 
                                                        <p><?php echo e($item->address); ?></p>
                                                    <?php endif; ?>
                                                </td>         
                                                <td> 
                                                    <button class="btn-icon btn block"><i class="fas fa-user-friends"></i></button>
                                                    <span class="tbl-info"><?php echo e($item->people .' allowed'); ?></span>
                                                </td>   
                                                <td> 
                                                    <button class="btn-icon btn block"><i class="fas fa-ticket-alt"></i></button>
                                                    <span class="tbl-info"><?php echo e($item->avaliable); ?> <?php echo e(__('Pcs left')); ?></span>
                                                </td>                                                                                                                    
                                                <td> 
                                                    <button class="btn-icon btn block"><i class="far fa-calendar-alt"></i></button>
                                                    <span class="tbl-info"><?php echo e($item->start_time->format('Y-m-d')); ?></span>
                                                </td>   
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3">
                <div class="card">
                  <div class="card-body calender-event">                
                    <input type="hidden" name="eventDate" id="eventDate" value="<?php echo e(json_encode($master['eventDate'])); ?>">
                    <div id="home_calender"></div>
                    <h5 class="text-dark mb-4 mt-2"><?php echo e(carbon\Carbon::now()->format('F').__(' Event')); ?></h5>
                    <div class="home-upcoming-event">
                      <?php if(count($monthEvent)==0): ?>
                      <div class="row">
                        <div class="col-12 text-center">
                          <div class="empty-data">
                            <div class="card-icon shadow-primary">
                              <i class="fas fa-search"></i>
                            </div>
                            <h6 class="mt-3"><?php echo e(__('No events found')); ?> </h6>
                          </div>                          
                        </div>
                      </div>
                      <?php else: ?> 
                        <?php $__currentLoopData = $monthEvent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row mb-4">
                          <div class="col-3">
                            <div class="date-left">
                              <h3 class="mb-0"><?php echo e($item->start_time->format('d')); ?></h3>
                              <p class="mb-0"><?php echo e($item->start_time->format('D')); ?></p>
                            </div>
                          </div>
                          <div class="col-9 event-right">
                            <p class="mb-0 name"><?php echo e($item->name); ?></p>
                            <p class="mb-0">Ticket Sold <span><?php echo e($item->sold_ticket); ?>/<?php echo e($item->tickets); ?></span></p>
                            <div class="progress mb-3" data-height="5">
                              <div class="progress-bar" role="progressbar" data-width="<?php echo e($item->average); ?>%" aria-valuenow="<?php echo e($item->average); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                          </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
               
                      
                    </div>
                  </div>
                  
                </div>
                
              </div>
        </div>
    
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\eventright\resources\views/admin/org_dashboard.blade.php ENDPATH**/ ?>